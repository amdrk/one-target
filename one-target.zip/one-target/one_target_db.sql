-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 24, 2026 at 02:11 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `one_target_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_cart` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `product_id`, `quantity`, `created_at`) VALUES
(1, 3, 7, 1, '2026-06-09 13:10:51'),
(14, 11, 1, 2, '2026-06-22 18:56:21'),
(15, 12, 1, 2, '2026-06-22 18:58:19');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `icon`, `created_at`) VALUES
(1, 'کارت گرافیک', 'graphics-card', 'images/categories/gpu.png', '2026-06-09 09:52:08'),
(2, 'پردازنده', 'cpu', 'images/categories/cpu.png', '2026-06-09 09:52:08'),
(3, 'مادربرد', 'motherboard', 'images/categories/motherboard.png', '2026-06-09 09:52:08'),
(4, 'رم', 'ram', 'images/categories/ram.png', '2026-06-09 09:52:08'),
(5, 'اس اس دی', 'ssd', 'images/categories/ssd.png', '2026-06-09 09:52:08'),
(6, 'منبع تغذیه', 'psu', 'images/categories/psu.png', '2026-06-09 09:52:08'),
(7, 'کیس', 'case', 'images/categories/case.png', '2026-06-09 09:52:08'),
(8, 'خنک کننده', 'cooler', 'images/categories/cooler.png', '2026-06-09 09:52:08'),
(9, 'مانیتور', 'monitor', 'images/categories/monitor.png', '2026-06-09 09:52:08'),
(10, 'لوازم جانبی', 'accessories', 'images/categories/accessories.png', '2026-06-09 09:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) COLLATE utf8mb4_persian_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `discount_amount` int(11) DEFAULT '0',
  `shipping_cost` int(11) DEFAULT '0',
  `final_amount` int(11) NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled') COLLATE utf8mb4_persian_ci DEFAULT 'pending',
  `payment_method` varchar(50) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `payment_status` enum('pending','paid','failed') COLLATE utf8mb4_persian_ci DEFAULT 'pending',
  `shipping_address` text COLLATE utf8mb4_persian_ci NOT NULL,
  `receiver_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `receiver_phone` varchar(20) COLLATE utf8mb4_persian_ci NOT NULL,
  `tracking_code` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_number`, `user_id`, `total_amount`, `discount_amount`, `shipping_cost`, `final_amount`, `status`, `payment_method`, `payment_status`, `shipping_address`, `receiver_name`, `receiver_phone`, `tracking_code`, `created_at`) VALUES
(1, 'ORD-1781123219-3066', 2, 12500000, 0, 0, 12500000, 'delivered', 'online', 'pending', 'سیلبالاتت', 'ممد', '11111111', NULL, '2026-06-10 20:26:59'),
(2, 'ORD-1781909152-4029', 2, 1000000, 0, 0, 1000000, 'pending', 'online', 'pending', 'الاتلاتللل', 'ممد', '11111111', NULL, '2026-06-19 22:45:52'),
(3, 'ORD-1781999605-2574', 4, 21390000, 0, 0, 21390000, 'pending', 'cash', 'pending', 'گچساران', 'علی', '09123213625', NULL, '2026-06-20 23:53:25'),
(4, 'ORD-1781999867-6306', 4, 13780000, 0, 0, 13780000, 'delivered', 'online', 'pending', 'sdsds', 'علی', '09123213625', NULL, '2026-06-20 23:57:47'),
(5, 'ORD-1782046921-1146', 5, 32500000, 0, 0, 32500000, 'pending', 'online', 'pending', 'سیبلادتن', 'رضا', '09336542541', NULL, '2026-06-21 13:02:01'),
(6, 'ORD-1782048186-9898', 6, 7890000, 0, 0, 7890000, 'pending', 'cash', 'pending', 'یبالللالاتلالا', 'احمد', '11111111111', NULL, '2026-06-21 13:23:06'),
(7, 'ORD-1782048646-6337', 6, 12500000, 0, 0, 12500000, 'pending', 'cash', 'pending', 'بسبسبسبسب', 'احمد', '11111111111', NULL, '2026-06-21 13:30:46'),
(8, 'ORD-1782049838-1842', 8, 12500000, 0, 0, 12500000, 'pending', 'cash', 'pending', 'ثسبلابلرا', 'جفر', '22222222222', NULL, '2026-06-21 13:50:38'),
(9, 'ORD-1782050018-2939', 9, 12500000, 0, 0, 12500000, 'pending', 'online', 'pending', 'یسبسبسب', 'قلی', '1111', NULL, '2026-06-21 13:53:38');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `price` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `price`, `quantity`, `total`) VALUES
(1, 1, 4, 'رم G.Skill Trident Z5 RGB 32GB', 12500000, 1, 12500000),
(3, 3, 6, 'منبع تغذیه Corsair RM1000e 1000W', 14500000, 1, 14500000),
(4, 3, 10, 'کیبورد Logitech G Pro X', 6890000, 1, 6890000),
(5, 4, 10, 'کیبورد Logitech G Pro X', 6890000, 2, 13780000),
(6, 5, 2, 'پردازنده Intel Core i9-14900K', 32500000, 1, 32500000),
(7, 6, 7, 'کیس NZXT H9 Flow', 7890000, 1, 7890000),
(8, 7, 4, 'رم G.Skill Trident Z5 RGB 32GB', 12500000, 1, 12500000),
(9, 8, 4, 'رم G.Skill Trident Z5 RGB 32GB', 12500000, 1, 12500000),
(10, 9, 4, 'رم G.Skill Trident Z5 RGB 32GB', 12500000, 1, 12500000);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `name_fa` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `description` text COLLATE utf8mb4_persian_ci,
  `short_desc` varchar(500) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `price` int(11) NOT NULL,
  `old_price` int(11) DEFAULT NULL,
  `discount_percent` int(11) DEFAULT '0',
  `image` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `image2` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `image3` varchar(255) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `brand` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `warranty` varchar(100) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `stock` int(11) DEFAULT '10',
  `rating_avg` decimal(2,1) DEFAULT '0.0',
  `review_count` int(11) DEFAULT '0',
  `views` int(11) DEFAULT '0',
  `is_featured` tinyint(1) DEFAULT '0',
  `is_new` tinyint(1) DEFAULT '1',
  `is_best_seller` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `name_fa`, `description`, `short_desc`, `price`, `old_price`, `discount_percent`, `image`, `image2`, `image3`, `category_id`, `brand`, `warranty`, `stock`, `rating_avg`, `review_count`, `views`, `is_featured`, `is_new`, `is_best_seller`, `created_at`) VALUES
(1, 'NVIDIA RTX 4080 Super', 'کارت گرافیک NVIDIA RTX 4080 Super', 'قوی‌ترین کارت گرافیک برای گیمینگ 4K و رندرینگ حرفه‌ای با 16GB حافظه GDDR6X', 'کارت گرافیک قدرتمند با 16GB رم', 84999000, 89999000, 6, 'images/products/product_1781997856_66f71db0.jpg', NULL, NULL, 1, 'NVIDIA', '36 ماهه', 15, '4.9', 128, 18, 1, 1, 1, '2026-06-09 09:52:08'),
(2, 'Intel Core i9-14900K', 'پردازنده Intel Core i9-14900K', 'قدرتمندترین پردازنده نسل چهاردهم اینتل با 24 هسته و 32 رشته', 'پردازنده 24 هسته ای نسل 14', 32500000, 35900000, 9, 'images/products/product_1781998007_8ed5820b.webp', NULL, NULL, 2, 'Intel', '36 ماهه', 11, '4.8', 95, 11, 1, 1, 1, '2026-06-09 09:52:08'),
(3, 'ASUS ROG Maximus Z790', 'مادربرد ASUS ROG Maximus Z790', 'مادربرد پرچمدار ایسوس برای پردازنده‌های نسل 13 و 14 اینتل', 'مادربرد حرفه‌ای Z790', 18999000, 21999000, 14, 'images/products/product_1781998033_571407a4.webp', NULL, NULL, 3, 'ASUS', '36 ماهه', 8, '4.7', 67, 8, 1, 1, 0, '2026-06-09 09:52:08'),
(4, 'G.Skill Trident Z5 RGB', 'رم G.Skill Trident Z5 RGB 32GB', 'رم 32 گیگابایت DDR5 با سرعت 6000MHz', 'رم 32GB DDR5 6000MHz', 12500000, 14900000, 16, 'images/products/product_1781998052_64450fdb.webp', NULL, NULL, 4, 'G.Skill', '24 ماهه', 16, '4.9', 112, 30, 1, 1, 1, '2026-06-09 09:52:08'),
(5, 'Samsung 990 PRO', 'اس اس دی Samsung 990 PRO 1TB', 'فوق سریعترین SSD NVMe با سرعت خواندن 7450MB/s', 'SSD 1TB NVMe PCIe 4.0', 8990000, 10990000, 18, 'images/products/product_1781998062_b42104b9.jpg', NULL, NULL, 5, 'Samsung', '60 ماهه', 25, '4.9', 203, 13, 1, 1, 1, '2026-06-09 09:52:08'),
(6, 'Corsair RM1000e', 'منبع تغذیه Corsair RM1000e 1000W', 'منبع تغذیه 1000 وات طلایی با گارانتی 10 ساله', 'پاور 1000 وات 80Plus Gold', 14500000, 16900000, 14, 'images/products/product_1781998079_70fd3530.jpg', NULL, NULL, 6, 'Corsair', '120 ماهه', 9, '4.8', 89, 2, 1, 0, 1, '2026-06-09 09:52:08'),
(7, 'NZXT H9 Flow', 'کیس NZXT H9 Flow', 'کیس شیشه‌ای با طراحی مدرن و جریان هوای عالی', 'کیس گیمینگ با نمای تمام شیشه', 7890000, 8990000, 12, 'images/products/product_1781998088_224d02ba.jpg', NULL, NULL, 7, 'NZXT', '24 ماهه', 6, '4.6', 54, 3, 1, 1, 0, '2026-06-09 09:52:08'),
(8, 'Deepcool LT720', 'خنک کننده Deepcool LT720', 'خنک کننده آبی 360 میلی متری RGB', 'خنک کننده مایع 360mm', 8990000, 10990000, 18, 'images/products/product_1781998095_438d571f.jpg', NULL, NULL, 8, 'Deepcool', '60 ماهه', 9, '4.7', 43, 7, 0, 1, 0, '2026-06-09 09:52:08'),
(9, 'Samsung Odyssey G7', 'مانیتور Samsung Odyssey G7 32\"', 'مانیتور 32 اینچ منحنی 240Hz 4K', 'مانیتور گیمینگ 4K 240Hz', 28999000, 32999000, 12, 'images/products/product_1781998106_80a3c7f5.jpg', NULL, NULL, 9, 'Samsung', '36 ماهه', 5, '4.9', 78, 6, 1, 1, 1, '2026-06-09 09:52:08'),
(10, 'Logitech G Pro X', 'کیبورد Logitech G Pro X', 'کیبورد مکانیکال حرفه‌ای با سوئیچ های Hot-Swappable', 'کیبورد گیمینگ حرفه‌ای', 6890000, 7990000, 14, 'images/products/product_1781998120_845b07e0.png', NULL, NULL, 10, 'Logitech', '24 ماهه', 15, '4.8', 156, 8, 1, 0, 1, '2026-06-09 09:52:08');

-- --------------------------------------------------------

--
-- Table structure for table `product_specs`
--

DROP TABLE IF EXISTS `product_specs`;
CREATE TABLE IF NOT EXISTS `product_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `spec_name` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `spec_value` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `product_specs`
--

INSERT INTO `product_specs` (`id`, `product_id`, `spec_name`, `spec_value`) VALUES
(12, 1, 'پهنای باند', '736 GB/s'),
(11, 1, 'حافظه', '16GB GDDR6X'),
(13, 2, 'تعداد هسته', '24'),
(15, 3, 'فرم فاکتور', 'ATX'),
(17, 4, 'ظرفیت', '32GB (2x16GB)'),
(20, 5, 'سرعت خواندن', '7450 MB/s'),
(19, 5, 'ظرفیت', '1TB'),
(14, 2, 'مصرف', '125W'),
(16, 3, 'سوکت', 'LGA1700'),
(18, 4, 'فرکانس', '6000MHz');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
CREATE TABLE IF NOT EXISTS `reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `rating` tinyint(4) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_persian_ci NOT NULL,
  `is_approved` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_persian_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_persian_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_persian_ci,
  `is_admin` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `email`, `password`, `phone`, `address`, `is_admin`, `created_at`) VALUES
(1, 'مدیر سایت', 'admin@onetarget.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NULL, NULL, 1, '2026-06-09 09:52:08'),
(5, 'رضا', 'reza@gmail.com', '$2y$10$nXwmu4zaDKwltvbcXoaxQ.XI4mMy8NA2mtINe47D6Db.jon6H4Ka6', '09336542541', NULL, 0, '2026-06-21 12:59:52'),
(6, 'احمد', 'ahmad@gmail.com', '$2y$10$fyBoN9QIEGyMo5tQESGKr.B.rDr8/u5BnCEolA7IMjk1A2iTSx3pS', '11111111111', NULL, 0, '2026-06-21 13:17:21'),
(4, 'علی', 'ali@gmail.com', '$2y$10$J5dKCg3fDvGrtys74mVrBOZjiqqp58Nm3OWOvL4R4KE.okGb6uC4C', '09123213625', NULL, 0, '2026-06-20 23:51:51'),
(7, 'حسین', 'hossein@gmail.com', '$2y$10$VdOHIdq.ufQJQ7.Mvb9JwOWdtWZ4pTR4KJwdFVtktomQ1TtzzG8NS', '22222222222', NULL, 0, '2026-06-21 13:43:59'),
(8, 'جفر', 'jafar@gmail.com', '$2y$10$FHqp27E092Jle/QtPVWBU.Y3XtzRO1l/abCZA9StBUrpio4ZSF69K', '22222222222', NULL, 0, '2026-06-21 13:50:14'),
(9, 'قلی', 'g@gmail.com', '$2y$10$pcZfnaBKNJlIcOpHlph4YOQWu1Vk/PmtAg1owvFZrCB1rt5AxdSNW', '1111', NULL, 0, '2026-06-21 13:53:18'),
(10, 'حمیدرضا سجادیان', 'hmirezgames1383@gmail.com', '$2y$10$zVNtscC1TXAF25qkBS/vheOYYkaQp60iH9b9ltTtvp5xupy7sxRVi', '9171111111', NULL, 0, '2026-06-22 18:42:54'),
(12, 'mmd', 'mmd@gmail.com', '$2y$10$LuItZD4kNKJ6jmV8bCuXaOQMvQkZjytEweuUDz41IUtOYtPWfDyYW', '9171111111', NULL, 0, '2026-06-22 18:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `wishlist`
--

DROP TABLE IF EXISTS `wishlist`;
CREATE TABLE IF NOT EXISTS `wishlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_wishlist` (`user_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
