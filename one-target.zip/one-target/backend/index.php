<?php
// ========== تنظیمات هدر ==========
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ========== تنظیمات دیتابیس ==========
$host = 'localhost';
$dbname = 'one_target_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die(json_encode(['success' => false, 'error' => 'Database connection failed: ' . $e->getMessage()]));
}

session_start();

// ========== توابع کمکی ==========
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;
}

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function formatPrice($price) {
    return number_format($price, 0, '.', ',');
}

// ========== دریافت action ==========
$action = $_GET['action'] ?? $_POST['action'] ?? '';
$rawInput = file_get_contents('php://input');
$inputData = json_decode($rawInput, true) ?? [];

try {
    switch ($action) {
        
        // ==================== محصولات ====================
        case 'get-products':
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 20;
            $offset = ($page - 1) * $limit;
            
            $category = $_GET['category'] ?? null;
            $search = $_GET['search'] ?? null;
            $sort = $_GET['sort'] ?? 'newest';
            $minPrice = isset($_GET['min_price']) ? (int)$_GET['min_price'] : null;
            $maxPrice = isset($_GET['max_price']) ? (int)$_GET['max_price'] : null;
            
            $sql = "SELECT p.*, c.name as category_name, c.slug as category_slug 
                    FROM products p 
                    LEFT JOIN categories c ON p.category_id = c.id 
                    WHERE 1=1";
            $countSql = "SELECT COUNT(*) as total FROM products p WHERE 1=1";
            // ✅ آرایه پارامتر جدا برای هر کوئری، چون تعداد ? بین sql و countSql ممکنه فرق کنه
            $params = [];
            $countParams = [];
            
            // ✅ فیلتر دسته‌بندی — پشتیبانی از چند مقدار جدا شده با کاما
            if ($category) {
                $categories = array_filter(explode(',', $category));
                if (count($categories) > 0) {
                    $placeholders = implode(',', array_fill(0, count($categories), '?'));
                    $sql .= " AND c.slug IN ($placeholders)";
                    $countSql .= " AND category_id IN (SELECT id FROM categories WHERE slug IN ($placeholders))";
                    foreach ($categories as $c) {
                        $params[] = $c;
                        $countParams[] = $c;
                    }
                }
            }
            
            if ($search) {
                $sql .= " AND (p.name_fa LIKE ? OR p.name LIKE ?)";
                $countSql .= " AND (name_fa LIKE ? OR name LIKE ?)";
                $params[] = "%$search%";
                $params[] = "%$search%";
                $countParams[] = "%$search%";
                $countParams[] = "%$search%";
            }
            
            if ($minPrice !== null) {
                $sql .= " AND p.price >= ?";
                $countSql .= " AND price >= ?";
                $params[] = $minPrice;
                $countParams[] = $minPrice;
            }
            
            if ($maxPrice !== null) {
                $sql .= " AND p.price <= ?";
                $countSql .= " AND price <= ?";
                $params[] = $maxPrice;
                $countParams[] = $maxPrice;
            }
            
            // ✅ فیلتر برند — پشتیبانی از چند مقدار جدا شده با کاما
            $brand = $_GET['brand'] ?? null;
            if ($brand) {
                $brands = array_filter(explode(',', $brand));
                if (count($brands) > 0) {
                    $placeholders = implode(',', array_fill(0, count($brands), '?'));
                    $sql .= " AND p.brand IN ($placeholders)";
                    $countSql .= " AND brand IN ($placeholders)";
                    foreach ($brands as $b) {
                        $params[] = $b;
                        $countParams[] = $b;
                    }
                }
            }
            
            // ✅ فیلتر موجودی
            if (isset($_GET['in_stock']) && $_GET['in_stock'] == '1') {
                $sql .= " AND p.stock > 0";
                $countSql .= " AND stock > 0";
            }
            
            // ✅ فیلتر امتیاز
            $minRating = isset($_GET['min_rating']) ? (float)$_GET['min_rating'] : null;
            if ($minRating !== null) {
                $sql .= " AND p.rating_avg >= ?";
                $countSql .= " AND rating_avg >= ?";
                $params[] = $minRating;
                $countParams[] = $minRating;
            }
            
            // ✅ فیلتر محصولات ویژه
            if (isset($_GET['featured']) && $_GET['featured'] == '1') {
                $sql .= " AND p.is_featured = 1";
                $countSql .= " AND is_featured = 1";
            }
            
            switch ($sort) {
                case 'price_asc': $sql .= " ORDER BY p.price ASC"; break;
                case 'price_desc': $sql .= " ORDER BY p.price DESC"; break;
                case 'popular': $sql .= " ORDER BY p.views DESC"; break;
                case 'rating': $sql .= " ORDER BY p.rating_avg DESC"; break;
                case 'best_seller': $sql .= " ORDER BY p.is_best_seller DESC, p.views DESC"; break;
                default: $sql .= " ORDER BY p.created_at DESC";
            }
            
            $sql .= " LIMIT $limit OFFSET $offset";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $products = $stmt->fetchAll();
            
            $countStmt = $pdo->prepare($countSql);
            $countStmt->execute($countParams);
            $total = $countStmt->fetch()['total'];
            
            if (isLoggedIn()) {
                $wishStmt = $pdo->prepare("SELECT product_id FROM wishlist WHERE user_id = ?");
                $wishStmt->execute([$_SESSION['user_id']]);
                $wishlist = $wishStmt->fetchAll(PDO::FETCH_COLUMN);
                
                foreach ($products as &$product) {
                    $product['in_wishlist'] = in_array($product['id'], $wishlist);
                }
            }
            
            jsonResponse([
                'success' => true,
                'products' => $products,
                'total' => $total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]);
            break;
            
        case 'get-product':
            $id = $_GET['id'] ?? null;
            if (!$id) {
                jsonResponse(['success' => false, 'error' => 'Product ID required'], 400);
            }
            
            $stmt = $pdo->prepare("SELECT p.*, c.name as category_name, c.slug as category_slug 
                                   FROM products p 
                                   LEFT JOIN categories c ON p.category_id = c.id 
                                   WHERE p.id = ?");
            $stmt->execute([$id]);
            $product = $stmt->fetch();
            
            if (!$product) {
                jsonResponse(['success' => false, 'error' => 'Product not found'], 404);
            }
            
            $updateStmt = $pdo->prepare("UPDATE products SET views = views + 1 WHERE id = ?");
            $updateStmt->execute([$id]);
            
            $specStmt = $pdo->prepare("SELECT * FROM product_specs WHERE product_id = ?");
            $specStmt->execute([$id]);
            $specs = $specStmt->fetchAll();
            
            $reviewStmt = $pdo->prepare("SELECT r.*, u.fullname 
                                         FROM reviews r 
                                         JOIN users u ON r.user_id = u.id 
                                         WHERE r.product_id = ? AND r.is_approved = 1 
                                         ORDER BY r.created_at DESC");
            $reviewStmt->execute([$id]);
            $reviews = $reviewStmt->fetchAll();
            
            $relatedStmt = $pdo->prepare("SELECT * FROM products 
                                          WHERE category_id = ? AND id != ? 
                                          ORDER BY RAND() 
                                          LIMIT 4");
            $relatedStmt->execute([$product['category_id'], $id]);
            $related = $relatedStmt->fetchAll();
            
            $inWishlist = false;
            if (isLoggedIn()) {
                $wishStmt = $pdo->prepare("SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?");
                $wishStmt->execute([$_SESSION['user_id'], $id]);
                $inWishlist = $wishStmt->rowCount() > 0;
            }
            
            jsonResponse([
                'success' => true,
                'product' => $product,
                'specs' => $specs,
                'reviews' => $reviews,
                'related_products' => $related,
                'in_wishlist' => $inWishlist
            ]);
            break;
            
        case 'get-featured-products':
            $stmt = $pdo->prepare("SELECT * FROM products WHERE is_featured = 1 ORDER BY RAND() LIMIT 8");
            $stmt->execute();
            $products = $stmt->fetchAll();
            jsonResponse(['success' => true, 'products' => $products]);
            break;
            
        case 'get-new-products':
            $stmt = $pdo->prepare("SELECT * FROM products WHERE is_new = 1 ORDER BY created_at DESC LIMIT 8");
            $stmt->execute();
            $products = $stmt->fetchAll();
            jsonResponse(['success' => true, 'products' => $products]);
            break;
            
        case 'get-best-sellers':
            $stmt = $pdo->prepare("SELECT * FROM products WHERE is_best_seller = 1 ORDER BY views DESC LIMIT 8");
            $stmt->execute();
            $products = $stmt->fetchAll();
            jsonResponse(['success' => true, 'products' => $products]);
            break;
            
        case 'get-categories':
            $stmt = $pdo->query("SELECT * FROM categories ORDER BY name");
            $categories = $stmt->fetchAll();
            
            foreach ($categories as &$cat) {
                $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM products WHERE category_id = ?");
                $countStmt->execute([$cat['id']]);
                $cat['product_count'] = $countStmt->fetch()['count'];
            }
            
            jsonResponse(['success' => true, 'categories' => $categories]);
            break;
            
        // ==================== سبد خرید ====================
        case 'get-cart':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $stmt = $pdo->prepare("SELECT c.id as cart_id, c.quantity, p.* 
                                   FROM cart c 
                                   JOIN products p ON c.product_id = p.id 
                                   WHERE c.user_id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $items = $stmt->fetchAll();
            
            $subtotal = 0;
            foreach ($items as &$item) {
                $item['total'] = $item['price'] * $item['quantity'];
                $subtotal += $item['total'];
            }
            
            jsonResponse([
                'success' => true,
                'items' => $items,
                'subtotal' => $subtotal,
                'shipping' => $subtotal > 500000 ? 0 : 50000,
                'total' => $subtotal + ($subtotal > 500000 ? 0 : 50000),
                'count' => count($items)
            ]);
            break;
            
        case 'add-to-cart':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $product_id = $inputData['product_id'] ?? null;
            $quantity = $inputData['quantity'] ?? 1;
            
            if (!$product_id) {
                jsonResponse(['success' => false, 'error' => 'Product ID required'], 400);
            }
            
            if ($quantity < 1) $quantity = 1;
            
            $stockStmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
            $stockStmt->execute([$product_id]);
            $stock = $stockStmt->fetch()['stock'] ?? 0;
            
            $currentStmt = $pdo->prepare("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?");
            $currentStmt->execute([$_SESSION['user_id'], $product_id]);
            $currentQty = $currentStmt->fetch()['quantity'] ?? 0;
            
            if ($currentQty + $quantity > $stock) {
                jsonResponse(['success' => false, 'error' => 'موجودی کافی نیست'], 400);
            }
            
            $stmt = $pdo->prepare("INSERT INTO cart (user_id, product_id, quantity) 
                                   VALUES (?, ?, ?) 
                                   ON DUPLICATE KEY UPDATE quantity = quantity + ?");
            $stmt->execute([$_SESSION['user_id'], $product_id, $quantity, $quantity]);
            
            jsonResponse(['success' => true, 'message' => 'به سبد خرید اضافه شد']);
            break;
            
        case 'update-cart':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $cart_id = $inputData['cart_id'] ?? null;
            $quantity = $inputData['quantity'] ?? 1;
            
            if (!$cart_id) {
                jsonResponse(['success' => false, 'error' => 'Cart ID required'], 400);
            }
            
            if ($quantity <= 0) {
                $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
                $stmt->execute([$cart_id, $_SESSION['user_id']]);
            } else {
                $stmt = $pdo->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
                $stmt->execute([$quantity, $cart_id, $_SESSION['user_id']]);
            }
            
            jsonResponse(['success' => true, 'message' => 'سبد خرید به‌روز شد']);
            break;
            
        case 'remove-from-cart':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $cart_id = $inputData['cart_id'] ?? null;
            if (!$cart_id) {
                jsonResponse(['success' => false, 'error' => 'Cart ID required'], 400);
            }
            
            $stmt = $pdo->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
            $stmt->execute([$cart_id, $_SESSION['user_id']]);
            
            jsonResponse(['success' => true, 'message' => 'از سبد خرید حذف شد']);
            break;
            
        // ==================== علاقه‌مندی‌ها ====================
        case 'get-wishlist':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $stmt = $pdo->prepare("SELECT p.* 
                                   FROM wishlist w 
                                   JOIN products p ON w.product_id = p.id 
                                   WHERE w.user_id = ? 
                                   ORDER BY w.created_at DESC");
            $stmt->execute([$_SESSION['user_id']]);
            $products = $stmt->fetchAll();
            
            jsonResponse(['success' => true, 'products' => $products]);
            break;
            
        case 'toggle-wishlist':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $product_id = $inputData['product_id'] ?? null;
            if (!$product_id) {
                jsonResponse(['success' => false, 'error' => 'Product ID required'], 400);
            }
            
            $checkStmt = $pdo->prepare("SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?");
            $checkStmt->execute([$_SESSION['user_id'], $product_id]);
            
            if ($checkStmt->rowCount() > 0) {
                $deleteStmt = $pdo->prepare("DELETE FROM wishlist WHERE user_id = ? AND product_id = ?");
                $deleteStmt->execute([$_SESSION['user_id'], $product_id]);
                jsonResponse(['success' => true, 'action' => 'removed', 'message' => 'از علاقه‌مندی‌ها حذف شد']);
            } else {
                $insertStmt = $pdo->prepare("INSERT INTO wishlist (user_id, product_id) VALUES (?, ?)");
                $insertStmt->execute([$_SESSION['user_id'], $product_id]);
                jsonResponse(['success' => true, 'action' => 'added', 'message' => 'به علاقه‌مندی‌ها اضافه شد']);
            }
            break;
            
        // ==================== احراز هویت ====================
        case 'register':
            $fullname = trim($inputData['fullname'] ?? '');
            $email = trim($inputData['email'] ?? '');
            $password = $inputData['password'] ?? '';
            $phone = $inputData['phone'] ?? '';
            
            if (!$fullname || !$email || !$password) {
                jsonResponse(['success' => false, 'error' => 'تمام فیلدها الزامی است'], 400);
            }
            
            if (!validateEmail($email)) {
                jsonResponse(['success' => false, 'error' => 'ایمیل نامعتبر است'], 400);
            }
            
            if (strlen($password) < 6) {
                jsonResponse(['success' => false, 'error' => 'رمز عبور باید حداقل 6 کاراکتر باشد'], 400);
            }
            
            $checkStmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $checkStmt->execute([$email]);
            if ($checkStmt->rowCount() > 0) {
                jsonResponse(['success' => false, 'error' => 'این ایمیل قبلاً ثبت شده است'], 400);
            }
            
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, phone, is_admin) VALUES (?, ?, ?, ?, 0)");
$stmt->execute([$fullname, $email, $hashedPassword, $phone]);
            // $stmt = $pdo->prepare("INSERT INTO users (fullname, email, password, phone) VALUES (?, ?, ?, ?)");
            // $stmt->execute([$fullname, $email, $hashedPassword, $phone]);
            
            $userId = $pdo->lastInsertId();
            $_SESSION['user_id'] = $userId;
            $_SESSION['fullname'] = $fullname;
            
            jsonResponse([
                'success' => true,
                'message' => 'ثبت‌نام با موفقیت انجام شد',
                'user' => ['id' => $userId, 'fullname' => $fullname, 'email' => $email]
            ]);
            break;
            
        case 'login':
            $email = trim($inputData['email'] ?? '');
            $password = $inputData['password'] ?? '';
            
            if (!$email || !$password) {
                jsonResponse(['success' => false, 'error' => 'ایمیل و رمز عبور الزامی است'], 400);
            }
            
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['is_admin'] = $user['is_admin'];
                
                jsonResponse([
                    'success' => true,
                    'message' => 'ورود با موفقیت انجام شد',
                    'fullname' => $user['fullname'],
                    'is_admin' => $user['is_admin']
                ]);
            } else {
                jsonResponse(['success' => false, 'error' => 'ایمیل یا رمز عبور اشتباه است'], 401);
            }
            break;
            
        case 'logout':
            session_destroy();
            jsonResponse(['success' => true, 'message' => 'خروج با موفقیت انجام شد']);
            break;
            
        case 'check-auth':
            if (isLoggedIn()) {
                jsonResponse([
                    'success' => true,
                    'logged_in' => true,
                    'fullname' => $_SESSION['fullname'],
                    'is_admin' => $_SESSION['is_admin'] ?? 0
                ]);
            } else {
                jsonResponse(['success' => true, 'logged_in' => false]);
            }
            break;
            
        // ==================== پروفایل کاربر ====================
        case 'get-user-profile':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $stmt = $pdo->prepare("SELECT id, fullname, email, phone, address, created_at FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if ($user) {
                jsonResponse(['success' => true, 'user' => $user]);
            } else {
                jsonResponse(['success' => false, 'error' => 'User not found'], 404);
            }
            break;
            
        case 'update-user-profile':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $fullname = trim($inputData['fullname'] ?? '');
            $phone = trim($inputData['phone'] ?? '');
            $address = trim($inputData['address'] ?? '');
            
            if (empty($fullname)) {
                jsonResponse(['success' => false, 'error' => 'نام و نام خانوادگی الزامی است'], 400);
            }
            
            $stmt = $pdo->prepare("UPDATE users SET fullname = ?, phone = ?, address = ? WHERE id = ?");
            $stmt->execute([$fullname, $phone, $address, $_SESSION['user_id']]);
            
            $_SESSION['fullname'] = $fullname;
            
            jsonResponse(['success' => true, 'message' => 'پروفایل با موفقیت به‌روز شد']);
            break;
            
        case 'change-password':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'Please login'], 401);
            }
            
            $current_password = $inputData['current_password'] ?? '';
            $new_password = $inputData['new_password'] ?? '';
            
            if (empty($current_password) || empty($new_password)) {
                jsonResponse(['success' => false, 'error' => 'رمز عبور فعلی و جدید الزامی است'], 400);
            }
            
            if (strlen($new_password) < 6) {
                jsonResponse(['success' => false, 'error' => 'رمز عبور جدید باید حداقل ۶ کاراکتر باشد'], 400);
            }
            
            $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
            $user = $stmt->fetch();
            
            if (!$user || !password_verify($current_password, $user['password'])) {
                jsonResponse(['success' => false, 'error' => 'رمز عبور فعلی اشتباه است'], 401);
            }
            
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $updateStmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $updateStmt->execute([$hashed_password, $_SESSION['user_id']]);
            
            jsonResponse(['success' => true, 'message' => 'رمز عبور با موفقیت تغییر کرد']);
            break;
            
        // ==================== نظرات ====================
        case 'get-reviews':
            $product_id = $_GET['product_id'] ?? null;
            if (!$product_id) {
                jsonResponse(['success' => false, 'error' => 'Product ID required'], 400);
            }
            
            $stmt = $pdo->prepare("SELECT r.*, u.fullname 
                                   FROM reviews r 
                                   JOIN users u ON r.user_id = u.id 
                                   WHERE r.product_id = ? AND r.is_approved = 1 
                                   ORDER BY r.created_at DESC");
            $stmt->execute([$product_id]);
            $reviews = $stmt->fetchAll();
            
            $statsStmt = $pdo->prepare("SELECT 
                                        AVG(rating) as avg_rating, 
                                        COUNT(*) as total,
                                        SUM(CASE WHEN rating = 5 THEN 1 ELSE 0 END) as five_star,
                                        SUM(CASE WHEN rating = 4 THEN 1 ELSE 0 END) as four_star,
                                        SUM(CASE WHEN rating = 3 THEN 1 ELSE 0 END) as three_star,
                                        SUM(CASE WHEN rating = 2 THEN 1 ELSE 0 END) as two_star,
                                        SUM(CASE WHEN rating = 1 THEN 1 ELSE 0 END) as one_star
                                       FROM reviews 
                                       WHERE product_id = ? AND is_approved = 1");
            $statsStmt->execute([$product_id]);
            $stats = $statsStmt->fetch();
            
            jsonResponse([
                'success' => true,
                'reviews' => $reviews,
                'stats' => [
                    'average' => round($stats['avg_rating'] ?? 0, 1),
                    'total' => $stats['total'] ?? 0,
                    'distribution' => [
                        5 => $stats['five_star'] ?? 0,
                        4 => $stats['four_star'] ?? 0,
                        3 => $stats['three_star'] ?? 0,
                        2 => $stats['two_star'] ?? 0,
                        1 => $stats['one_star'] ?? 0
                    ]
                ]
            ]);
            break;
            
        case 'add-review':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'برای ثبت نظر وارد شوید'], 401);
            }
            
            $product_id = $inputData['product_id'] ?? null;
            $rating = $inputData['rating'] ?? null;
            $comment = trim($inputData['comment'] ?? '');
            
            if (!$product_id || !$rating || !$comment) {
                jsonResponse(['success' => false, 'error' => 'تمام فیلدها الزامی است'], 400);
            }
            
            if ($rating < 1 || $rating > 5) {
                jsonResponse(['success' => false, 'error' => 'امتیاز باید بین 1 تا 5 باشد'], 400);
            }
            
            $checkStmt = $pdo->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
            $checkStmt->execute([$_SESSION['user_id'], $product_id]);
            if ($checkStmt->rowCount() > 0) {
                jsonResponse(['success' => false, 'error' => 'شما قبلاً برای این محصول نظر ثبت کرده‌اید'], 400);
            }
            
            $stmt = $pdo->prepare("INSERT INTO reviews (user_id, product_id, rating, comment, is_approved) VALUES (?, ?, ?, ?, 0)");
            $stmt->execute([$_SESSION['user_id'], $product_id, $rating, $comment]);
            
            jsonResponse(['success' => true, 'message' => 'نظر شما با موفقیت ثبت شد و پس از تأیید نمایش داده می‌شود']);
            break;
            
        // ==================== سفارشات ====================
        case 'create-order':
            if (!isLoggedIn()) {
                jsonResponse(['success' => false, 'error' => 'لطفاً وارد شوید'], 401);
            }
            
            $receiver_name = trim($inputData['receiver_name'] ?? '');
            $receiver_phone = trim($inputData['receiver_phone'] ?? '');
            $shipping_address = trim($inputData['shipping_address'] ?? '');
            $payment_method = $inputData['payment_method'] ?? 'online';
            
            if (!$receiver_name || !$receiver_phone || !$shipping_address) {
                jsonResponse(['success' => false, 'error' => 'اطلاعات تحویل گیرنده الزامی است'], 400);
            }
            
            $cartStmt = $pdo->prepare("SELECT c.*, p.price, p.name_fa as product_name 
                                       FROM cart c 
                                       JOIN products p ON c.product_id = p.id 
                                       WHERE c.user_id = ?");
            $cartStmt->execute([$_SESSION['user_id']]);
            $cartItems = $cartStmt->fetchAll();
            
            if (empty($cartItems)) {
                jsonResponse(['success' => false, 'error' => 'سبد خرید شما خالی است'], 400);
            }
            
            $subtotal = 0;
            foreach ($cartItems as $item) {
                $subtotal += $item['price'] * $item['quantity'];
            }
            
            $shipping_cost = $subtotal > 500000 ? 0 : 50000;
            $final_amount = $subtotal + $shipping_cost;
            $order_number = 'ORD-' . time() . '-' . rand(1000, 9999);
            
            $pdo->beginTransaction();
            
            try {
                $orderStmt = $pdo->prepare("INSERT INTO orders (order_number, user_id, total_amount, shipping_cost, final_amount, payment_method, shipping_address, receiver_name, receiver_phone, status, payment_status) 
                                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'pending')");
                $orderStmt->execute([$order_number, $_SESSION['user_id'], $subtotal, $shipping_cost, $final_amount, $payment_method, $shipping_address, $receiver_name, $receiver_phone]);
                $order_id = $pdo->lastInsertId();
                
//                 $orderStmt = $pdo->prepare("INSERT INTO orders (order_number, user_id, total_amount, shipping_cost, final_amount, payment_method, shipping_address, receiver_name, receiver_phone, status, payment_status) 
//                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 'paid')");
// $orderStmt->execute([$order_number, $_SESSION['user_id'], $subtotal, $shipping_cost, $final_amount, $payment_method, $shipping_address, $receiver_name, $receiver_phone]);
// $order_id = $pdo->lastInsertId();


                foreach ($cartItems as $item) {
                    $itemStmt = $pdo->prepare("INSERT INTO order_items (order_id, product_id, product_name, price, quantity, total) 
                                               VALUES (?, ?, ?, ?, ?, ?)");
                    $itemStmt->execute([$order_id, $item['product_id'], $item['product_name'], $item['price'], $item['quantity'], $item['price'] * $item['quantity']]);
                    
                    $updateStock = $pdo->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                    $updateStock->execute([$item['quantity'], $item['product_id']]);
                }
                
                $clearCart = $pdo->prepare("DELETE FROM cart WHERE user_id = ?");
                $clearCart->execute([$_SESSION['user_id']]);
                
                $pdo->commit();
                
                jsonResponse([
                    'success' => true,
                    'message' => 'سفارش شما با موفقیت ثبت شد',
                    'order_id' => $order_id,
                    'order_number' => $order_number,
                    'final_amount' => $final_amount
                ]);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                jsonResponse(['success' => false, 'error' => 'خطا در ثبت سفارش: ' . $e->getMessage()], 500);
            }
            break;
            
        case 'get-orders':
    if (!isLoggedIn()) {
        jsonResponse(['success' => false, 'error' => 'Please login'], 401);
    }
    
    // اگر ادمین هست، همه سفارشات رو برگردون
    if (isAdmin()) {
        $stmt = $pdo->prepare("SELECT * FROM orders ORDER BY created_at DESC");
        $stmt->execute();
        $orders = $stmt->fetchAll();
        
        foreach ($orders as &$order) {
            $itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $itemStmt->execute([$order['id']]);
            $order['items'] = $itemStmt->fetchAll();
        }
    } else {
        // کاربر عادی فقط سفارشات خودش رو ببینه
        $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
        $stmt->execute([$_SESSION['user_id']]);
        $orders = $stmt->fetchAll();
        
        foreach ($orders as &$order) {
            $itemStmt = $pdo->prepare("SELECT * FROM order_items WHERE order_id = ?");
            $itemStmt->execute([$order['id']]);
            $order['items'] = $itemStmt->fetchAll();
        }
    }
    
    jsonResponse(['success' => true, 'orders' => $orders]);
    break;
            
        // ==================== جستجو ====================
        case 'search':
            $q = $_GET['q'] ?? '';
            if (strlen($q) < 2) {
                jsonResponse(['success' => true, 'products' => []]);
            }
            
            $stmt = $pdo->prepare("SELECT * FROM products WHERE name_fa LIKE ? OR name LIKE ? LIMIT 20");
            $stmt->execute(["%$q%", "%$q%"]);
            $products = $stmt->fetchAll();
            
            jsonResponse(['success' => true, 'products' => $products]);
            break;
            // ==================== مدیریت محصولات (ادمین) ====================
case 'get-users':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    $stmt = $pdo->query("SELECT id, fullname, email, phone, is_admin, created_at FROM users ORDER BY created_at DESC");
    $users = $stmt->fetchAll();
    jsonResponse(['success' => true, 'users' => $users]);
    break;

// ✅ آپلود عکس محصول — multipart/form-data (نه JSON)
case 'upload-image':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    
    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        jsonResponse(['success' => false, 'error' => 'فایلی ارسال نشده یا خطا در آپلود'], 400);
    }
    
    $file = $_FILES['image'];
    
    // اعتبارسنجی نوع فایل
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);
    
    if (!in_array($mimeType, $allowedTypes)) {
        jsonResponse(['success' => false, 'error' => 'فقط فایل‌های تصویری (jpg, png, webp, gif) مجاز هستند'], 400);
    }
    
    // اعتبارسنجی حجم (حداکثر 5 مگابایت)
    if ($file['size'] > 5 * 1024 * 1024) {
        jsonResponse(['success' => false, 'error' => 'حجم فایل نباید بیشتر از 5 مگابایت باشد'], 400);
    }
    
    // پوشه ذخیره‌سازی
    $uploadDir = __DIR__ . '/../images/products/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    // اسم یکتا برای فایل
    $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
    $safeExt = strtolower(preg_replace('/[^a-z0-9]/i', '', $ext));
    $fileName = 'product_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $safeExt;
    $destination = $uploadDir . $fileName;
    
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        jsonResponse(['success' => false, 'error' => 'خطا در ذخیره فایل'], 500);
    }
    
    // مسیری که در دیتابیس و فرانت‌اند استفاده میشه
    $imagePath = 'images/products/' . $fileName;
    
    jsonResponse(['success' => true, 'message' => 'عکس با موفقیت آپلود شد', 'image' => $imagePath]);
    break;

case 'add-product':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    
    $name = $inputData['name'] ?? '';
    $name_fa = $inputData['name_fa'] ?? '';
    $category_id = $inputData['category_id'] ?? null;
    $brand = $inputData['brand'] ?? '';
    $price = $inputData['price'] ?? 0;
    $old_price = $inputData['old_price'] ?? null;
    $discount_percent = $inputData['discount_percent'] ?? 0;
    $stock = $inputData['stock'] ?? 10;
    $short_desc = $inputData['short_desc'] ?? '';
    $description = $inputData['description'] ?? '';
    $warranty = $inputData['warranty'] ?? '';
    $is_featured = $inputData['is_featured'] ?? 0;
    $is_new = $inputData['is_new'] ?? 1;
    $image = $inputData['image'] ?? null;
    $specs = json_decode($inputData['specs'] ?? '[]', true);
    
    if (empty($name_fa) || empty($price)) {
        jsonResponse(['success' => false, 'error' => 'نام محصول و قیمت الزامی است'], 400);
    }
    
    $stmt = $pdo->prepare("INSERT INTO products (name, name_fa, category_id, brand, price, old_price, discount_percent, stock, short_desc, description, warranty, is_featured, is_new, image) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $name_fa, $category_id, $brand, $price, $old_price, $discount_percent, $stock, $short_desc, $description, $warranty, $is_featured, $is_new, $image]);
    $product_id = $pdo->lastInsertId();
    
    // ذخیره ویژگی‌ها
    foreach ($specs as $spec) {
        $specStmt = $pdo->prepare("INSERT INTO product_specs (product_id, spec_name, spec_value) VALUES (?, ?, ?)");
        $specStmt->execute([$product_id, $spec['name'], $spec['value']]);
    }
    
    jsonResponse(['success' => true, 'message' => 'محصول با موفقیت اضافه شد', 'id' => $product_id]);
    break;

case 'update-product':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    
    $id = $inputData['id'] ?? 0;
    $name = $inputData['name'] ?? '';
    $name_fa = $inputData['name_fa'] ?? '';
    $category_id = $inputData['category_id'] ?? null;
    $brand = $inputData['brand'] ?? '';
    $price = $inputData['price'] ?? 0;
    $old_price = $inputData['old_price'] ?? null;
    $discount_percent = $inputData['discount_percent'] ?? 0;
    $stock = $inputData['stock'] ?? 10;
    $short_desc = $inputData['short_desc'] ?? '';
    $description = $inputData['description'] ?? '';
    $warranty = $inputData['warranty'] ?? '';
    $is_featured = $inputData['is_featured'] ?? 0;
    $is_new = $inputData['is_new'] ?? 1;
    $specs = json_decode($inputData['specs'] ?? '[]', true);
    
    // ✅ عکس فقط در صورتی که فرستاده شده باشه آپدیت میشه (در غیر این صورت عکس قبلی حفظ میشه)
    if (array_key_exists('image', $inputData) && !empty($inputData['image'])) {
        $stmt = $pdo->prepare("UPDATE products SET name=?, name_fa=?, category_id=?, brand=?, price=?, old_price=?, discount_percent=?, stock=?, short_desc=?, description=?, warranty=?, is_featured=?, is_new=?, image=? WHERE id=?");
        $stmt->execute([$name, $name_fa, $category_id, $brand, $price, $old_price, $discount_percent, $stock, $short_desc, $description, $warranty, $is_featured, $is_new, $inputData['image'], $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE products SET name=?, name_fa=?, category_id=?, brand=?, price=?, old_price=?, discount_percent=?, stock=?, short_desc=?, description=?, warranty=?, is_featured=?, is_new=? WHERE id=?");
        $stmt->execute([$name, $name_fa, $category_id, $brand, $price, $old_price, $discount_percent, $stock, $short_desc, $description, $warranty, $is_featured, $is_new, $id]);
    }
    
    // حذف ویژگی‌های قدیمی و اضافه کردن جدید
    $delStmt = $pdo->prepare("DELETE FROM product_specs WHERE product_id = ?");
    $delStmt->execute([$id]);
    
    foreach ($specs as $spec) {
        $specStmt = $pdo->prepare("INSERT INTO product_specs (product_id, spec_name, spec_value) VALUES (?, ?, ?)");
        $specStmt->execute([$id, $spec['name'], $spec['value']]);
    }
    
    jsonResponse(['success' => true, 'message' => 'محصول با موفقیت به‌روز شد']);
    break;

case 'delete-product':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    
    $id = $inputData['id'] ?? 0;
    $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
    $stmt->execute([$id]);
    
    jsonResponse(['success' => true, 'message' => 'محصول حذف شد']);
    break;

// ✅ لیست همه محصولات برای پنل ادمین (بدون فیلتر پیچیده مشتری)
case 'get-all-products':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    
    $stmt = $pdo->query("SELECT p.*, c.name as category_name 
                         FROM products p 
                         LEFT JOIN categories c ON p.category_id = c.id 
                         ORDER BY p.created_at DESC");
    $products = $stmt->fetchAll();
    
    jsonResponse(['success' => true, 'products' => $products]);
    break;
    
case 'update-order-status':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    $order_id = $inputData['order_id'] ?? 0;
    $status = $inputData['status'] ?? '';
    $validStatus = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!in_array($status, $validStatus)) {
        jsonResponse(['success' => false, 'error' => 'وضعیت نامعتبر'], 400);
    }
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);
    jsonResponse(['success' => true, 'message' => 'وضعیت به‌روز شد']);
    break;

case 'make-admin':
    if (!isLoggedIn() || !isAdmin()) {
        jsonResponse(['success' => false, 'error' => 'Unauthorized'], 401);
    }
    $user_id = $inputData['user_id'] ?? 0;
    $stmt = $pdo->prepare("UPDATE users SET is_admin = 1 WHERE id = ?");
    $stmt->execute([$user_id]);
    jsonResponse(['success' => true, 'message' => 'کاربر به مدیر تبدیل شد']);
    break;

        default:
            jsonResponse(['success' => false, 'error' => 'عملیات نامعتبر'], 400);
    }
    
} catch (PDOException $e) {
    jsonResponse(['success' => false, 'error' => 'خطای دیتابیس: ' . $e->getMessage()], 500);
}
?>