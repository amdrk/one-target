// js/ai-chat.js
// چت‌باکس هوش مصنوعی فروشگاهی - نسخه نهایی

class AIChat {
    constructor() {
        this.messages = [];
        this.isLoading = false;
        this.container = null;
        this.init();
    }

    init() {
        this.createToggleButton();
        this.createChatContainer();
        this.bindEvents();
    }

    createToggleButton() {
        const btn = document.createElement('button');
        btn.className = 'ai-chat-toggle';
        btn.id = 'aiChatToggle';
        btn.innerHTML = '🤖 <span class="badge">AI</span>';
        btn.title = 'دستیار هوشمند وان‌تارگت';
        document.body.appendChild(btn);
        this.toggleBtn = btn;
    }

    createChatContainer() {
        const container = document.createElement('div');
        container.className = 'ai-chat-container';
        container.id = 'aiChatContainer';
        container.innerHTML = `
            <div class="ai-chat-header">
                <h3>🤖 دستیار وان‌تارگت <span class="status"><span class="dot"></span>آنلاین</span></h3>
                <button class="close-btn" id="aiChatClose">✕</button>
            </div>
            <div class="ai-chat-body" id="aiChatBody">
                <div class="ai-chat-message assistant">
                    👋 سلام! من دستیار هوشمند وان‌تارگت هستم.<br>
                    می‌توانم به شما در انتخاب بهترین قطعه کامپیوتر کمک کنم.<br><br>
                    💡 <strong>مثلاً بپرسید:</strong><br>
                    • بهترین کارت گرافیک برای بازی کدومه؟<br>
                    • یه پردازنده خوب با قیمت ۲۰ میلیون پیشنهاد بده<br>
                    • چه مادربردی با اینتل نسل ۱۳ جور میشه؟
                </div>
                <div class="ai-chat-typing" id="aiChatTyping">
                    <div class="dots"><span></span><span></span><span></span></div>
                </div>
            </div>
            <div class="ai-chat-footer">
                <input type="text" id="aiChatInput" placeholder="سوال خود را بپرسید..." maxlength="500">
                <button id="aiChatSend">ارسال</button>
            </div>
        `;
        document.body.appendChild(container);
        this.container = container;
    }

    bindEvents() {
        this.toggleBtn.addEventListener('click', () => this.open());
        document.getElementById('aiChatClose').addEventListener('click', () => this.close());
        document.getElementById('aiChatSend').addEventListener('click', () => this.sendMessage());
        document.getElementById('aiChatInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.sendMessage();
            }
        });
    }

    open() {
        this.container.classList.add('open');
        document.getElementById('aiChatInput').focus();
    }

    close() {
        this.container.classList.remove('open');
    }

    async sendMessage() {
        const input = document.getElementById('aiChatInput');
        const message = input.value.trim();
        if (!message || this.isLoading) return;

        this.addMessage('user', message);
        input.value = '';
        this.isLoading = true;
        this.showTyping();

        try {
            const history = this.messages.slice(-5).map(m => ({
                role: m.type === 'user' ? 'user' : 'assistant',
                content: m.content
            }));

            const response = await fetch('/one-target/ai/assistant.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message, history })
            });

            const data = await response.json();
            this.hideTyping();

            if (data.success) {
                // ✅ بررسی کن که کاربر درخواست لیست همه محصولات رو داره
                const wantsAll = wantsAllProductsList(message);
                
                if (wantsAll) {
                    // اگه کاربر همه محصولات رو خواسته، لیست کامل رو از دیتابیس بگیر
                    const allProducts = await getAllProducts();
                    if (allProducts && allProducts.length > 0) {
                        this.addMessage('assistant', '📦 لیست تمام محصولات موجود در فروشگاه وان‌تارگت:', allProducts);
                    } else {
                        this.addMessage('assistant', 'متاسفانه محصولی در فروشگاه موجود نیست.', null);
                    }
                } else if (data.products && data.products.length > 0) {
                    // ✅ محصولات مرتبط رو نمایش بده
                    this.addMessage('assistant', data.reply, data.products);
                } else {
                    // بدون محصولات
                    this.addMessage('assistant', data.reply, null);
                }
            } else {
                this.addMessage('assistant', '❌ خطایی رخ داد. دوباره تلاش کن.');
            }
        } catch (error) {
            console.error('AI Chat Error:', error);
            this.hideTyping();
            this.addMessage('assistant', '❌ خطا در ارتباط با سرور.');
        }

        this.isLoading = false;
        this.scrollToBottom();
    }

    async getAllProducts() {
        try {
            const response = await fetch('/one-target/backend/index.php?action=get-products&limit=100');
            const data = await response.json();
            if (data.success && data.products) {
                return data.products;
            }
            return [];
        } catch (error) {
            console.error('Error loading all products:', error);
            return [];
        }
    }

    addMessage(type, content, products = null) {
        const body = document.getElementById('aiChatBody');
        const div = document.createElement('div');
        div.className = `ai-chat-message ${type}`;
        
        let displayContent = content;
        if (type === 'assistant') {
            displayContent = content.replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);
        }
        div.innerHTML = displayContent;

        // ✅ همیشه محصولات رو نمایش بده اگه وجود داشته باشن
        if (products && products.length > 0 && type === 'assistant') {
            const maxShow = products.length > 10 ? 10 : products.length;
            const productHtml = this.createProductSuggestions(products.slice(0, maxShow), products.length > 10);
            div.innerHTML += productHtml;
        }

        const typing = document.getElementById('aiChatTyping');
        body.insertBefore(div, typing);
        this.messages.push({ type, content: displayContent });
        this.scrollToBottom();
    }

    createProductSuggestions(products, hasMore = false) {
        if (!products || products.length === 0) return '';
        
        let html = `<div class="product-suggestion">
            <p style="font-size:12px; color:#ff6b00; margin-bottom:8px;">🛒 ${products.length > 1 ? 'محصولات پیشنهادی:' : 'محصول پیشنهادی:'}</p>`;
        
        products.forEach(p => {
            const price = Number(p.price).toLocaleString('fa-IR');
            const discount = p.discount_percent ? ` (${p.discount_percent}% تخفیف)` : '';
            html += `
                <div class="product-item" onclick="location.href='/one-target/product-detail.html?id=${p.id}'">
                    <img src="${p.image || '/one-target/images/placeholder.jpg'}" alt="${p.name_fa}">
                    <div class="info">
                        <div class="name">${p.name_fa}</div>
                        <div class="price">💰 ${price} تومان${discount}</div>
                    </div>
                    <a href="/one-target/product-detail.html?id=${p.id}" class="view-btn">مشاهده</a>
                </div>
            `;
        });
        
        if (hasMore) {
            html += `<p style="font-size:11px; color:#666; margin-top:8px; text-align:center;">+ ${products.length - 10} محصول دیگر در فروشگاه موجود است</p>`;
        }
        
        html += `</div>`;
        return html;
    }

    showTyping() {
        document.getElementById('aiChatTyping').style.display = 'flex';
        this.scrollToBottom();
    }

    hideTyping() {
        document.getElementById('aiChatTyping').style.display = 'none';
    }

    scrollToBottom() {
        const body = document.getElementById('aiChatBody');
        setTimeout(() => { body.scrollTop = body.scrollHeight; }, 50);
    }
}

// ========== تشخیص درخواست لیست همه محصولات ==========
function wantsAllProductsList(message) {
    const lowerMsg = message.toLowerCase();
    const keywords = [
        'همه محصولات', 'لیست محصولات', 'تمام محصولات',
        'همه رو بگو', 'همشون رو بگو', 'همه رو لیست کن',
        'چه محصولاتی داری', 'چی داری', 'محصولات موجود',
        'همه چی', 'همه موارد', 'همه کالاها', 'لیست کامل'
    ];
    
    for (const keyword of keywords) {
        if (lowerMsg.includes(keyword)) {
            return true;
        }
    }
    return false;
}

// ========== راه‌اندازی ==========
document.addEventListener('DOMContentLoaded', () => {
    const chat = new AIChat();
    window.aiChat = chat;
});