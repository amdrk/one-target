// js/orders.js
// توجه: API_URL، formatPrice، showMessage، apiCall از main.js میان

async function loadOrders() {
    const data = await apiCall('get-orders');

    if (data.success) {
        document.getElementById('loadingSpinner').style.display = 'none';
        if (data.orders && data.orders.length > 0) {
            displayOrders(data.orders);
            displayOrdersStats(data.orders);
            document.getElementById('ordersContent').style.display = 'block';
        } else {
            document.getElementById('loadingSpinner').innerHTML = `
                <div class="empty-state">
                    <h3>شما هنوز سفارشی ثبت نکرده‌اید</h3>
                    <a href="products.html" class="btn-primary">مشاهده محصولات</a>
                </div>
            `;
        }
    } else if (data.error === 'Please login') {
        window.location.href = 'index.html';
    } else {
        document.getElementById('loadingSpinner').innerHTML = '<p class="error">خطا در بارگذاری سفارشات</p>';
    }
}

function displayOrdersStats(orders) {
    const stats = {
        total: orders.length,
        pending: orders.filter(o => o.status === 'pending').length,
        delivered: orders.filter(o => o.status === 'delivered').length,
        totalAmount: orders.reduce((sum, o) => sum + Number(o.final_amount), 0)
    };

    const container = document.getElementById('ordersStats');
    if (!container) return;
    container.innerHTML = `
        <div class="stat-card"><div class="stat-value">${stats.total}</div><div class="stat-label">کل سفارشات</div></div>
        <div class="stat-card"><div class="stat-value">${stats.pending}</div><div class="stat-label">در انتظار پرداخت</div></div>
        <div class="stat-card"><div class="stat-value">${stats.delivered}</div><div class="stat-label">تحویل شده</div></div>
        <div class="stat-card"><div class="stat-value">${formatPrice(stats.totalAmount)}</div><div class="stat-label">مجموع خرید (تومان)</div></div>
    `;
}

function displayOrders(orders) {
    const container = document.getElementById('ordersList');
    if (!container) return;
    container.innerHTML = orders.map(order => createOrderCard(order)).join('');

    container.querySelectorAll('.view-details-btn').forEach(btn => {
        btn.addEventListener('click', () => showOrderDetails(btn.dataset.orderId, orders));
    });
}

function createOrderCard(order) {
    const statusMap = {
        'pending': 'در انتظار پرداخت',
        'processing': 'در حال پردازش',
        'shipped': 'ارسال شده',
        'delivered': 'تحویل داده شده',
        'cancelled': 'لغو شده'
    };
    const statusClass = {
        'pending': 'status-pending',
        'processing': 'status-processing',
        'shipped': 'status-shipped',
        'delivered': 'status-delivered',
        'cancelled': 'status-cancelled'
    };
    const paymentStatusMap = {
        'pending': 'در انتظار پرداخت',
        'paid': 'پرداخت شده',
        'failed': 'ناموفق'
    };

    const itemsHtml = (order.items || []).slice(0, 3).map(item => `
        <div class="order-item">
            <span class="order-item-name">${item.product_name}</span>
            <span class="order-item-price">${formatPrice(item.price)} تومان</span>
            <span class="order-item-quantity">× ${item.quantity}</span>
            <span class="order-item-total">${formatPrice(item.total)} تومان</span>
        </div>
    `).join('');

    const moreItems = (order.items?.length || 0) > 3 ?
        `<div class="order-more">+ ${order.items.length - 3} محصول دیگر</div>` : '';

    return `
        <div class="order-card">
            <div class="order-card-header">
                <div class="order-info">
                    <h3>سفارش <span>#${order.order_number}</span></h3>
                    <div class="order-date">${new Date(order.created_at).toLocaleDateString('fa-IR')}</div>
                </div>
                <div class="order-status-badge ${statusClass[order.status] || ''}">${statusMap[order.status] || order.status}</div>
                <div class="order-amount">
                    <div class="amount">${formatPrice(order.final_amount)} تومان</div>
                    <div class="payment-status">${paymentStatusMap[order.payment_status] || ''}</div>
                </div>
            </div>
            <div class="order-card-body">
                <div class="order-items">${itemsHtml}${moreItems}</div>
                <div class="order-shipping">هزینه ارسال: ${Number(order.shipping_cost) > 0 ? formatPrice(order.shipping_cost) + ' تومان' : 'رایگان'}</div>
            </div>
            <div class="order-footer">
                <div class="tracking-code">کد رهگیری: <span>${order.tracking_code || 'در حال ثبت'}</span></div>
                <button class="view-details-btn" data-order-id="${order.id}">مشاهده جزئیات</button>
            </div>
        </div>
    `;
}

// ✅ جزئیات از داده‌های موجود (بدون درخواست مجدد)
function showOrderDetails(orderId, orders) {
    const order = orders.find(o => o.id == orderId);
    if (!order) return;

    const modal = document.getElementById('orderDetailModal');
    const content = document.getElementById('orderDetailContent');
    if (!modal || !content) return;

    const statusMap = {
        'pending': 'در انتظار پرداخت',
        'processing': 'در حال پردازش',
        'shipped': 'ارسال شده',
        'delivered': 'تحویل داده شده',
        'cancelled': 'لغو شده'
    };

    content.innerHTML = `
        <div class="order-detail-section">
            <h4>اطلاعات سفارش</h4>
            <div class="detail-row"><div class="detail-label">شماره سفارش:</div><div class="detail-value">${order.order_number}</div></div>
            <div class="detail-row"><div class="detail-label">تاریخ ثبت:</div><div class="detail-value">${new Date(order.created_at).toLocaleDateString('fa-IR')}</div></div>
            <div class="detail-row"><div class="detail-label">وضعیت:</div><div class="detail-value">${statusMap[order.status] || order.status}</div></div>
            <div class="detail-row"><div class="detail-label">وضعیت پرداخت:</div><div class="detail-value">${order.payment_status === 'paid' ? 'پرداخت شده' : 'در انتظار پرداخت'}</div></div>
        </div>
        <div class="order-detail-section">
            <h4>آدرس تحویل</h4>
            <div class="detail-row"><div class="detail-label">گیرنده:</div><div class="detail-value">${order.receiver_name || '—'}</div></div>
            <div class="detail-row"><div class="detail-label">تلفن:</div><div class="detail-value">${order.receiver_phone || '—'}</div></div>
            <div class="detail-row"><div class="detail-label">آدرس:</div><div class="detail-value">${order.shipping_address || '—'}</div></div>
        </div>
        <div class="order-detail-section">
            <h4>محصولات سفارش</h4>
            ${(order.items || []).map(item => `
                <div class="detail-row">
                    <div class="detail-label">${item.product_name}</div>
                    <div class="detail-value">${formatPrice(item.price)} × ${item.quantity} = ${formatPrice(item.total)} تومان</div>
                </div>
            `).join('')}
            <div class="detail-row">
                <div class="detail-label">هزینه ارسال:</div>
                <div class="detail-value">${Number(order.shipping_cost) > 0 ? formatPrice(order.shipping_cost) + ' تومان' : 'رایگان'}</div>
            </div>
            <div class="detail-row">
                <div class="detail-label">مجموع:</div>
                <div class="detail-value"><strong>${formatPrice(order.final_amount)} تومان</strong></div>
            </div>
        </div>
        ${order.tracking_code ? `
        <div class="order-detail-section">
            <h4>کد رهگیری مرسوله</h4>
            <div class="detail-row"><div class="detail-value">${order.tracking_code}</div></div>
        </div>` : ''}
    `;

    document.getElementById('orderNumber').textContent = order.order_number;
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';

    const closeBtn = modal.querySelector('.modal-close');
    if (closeBtn) closeBtn.onclick = () => { modal.style.display = 'none'; document.body.style.overflow = 'auto'; };
    modal.onclick = (e) => { if (e.target === modal) { modal.style.display = 'none'; document.body.style.overflow = 'auto'; } };
}

document.addEventListener('DOMContentLoaded', () => {
    loadOrders();
});
