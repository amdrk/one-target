// js/ai-popup.js
// شگفت‌انگیزه هوش مصنوعی (پاپ‌آپ شناور با تایمر)

document.addEventListener('DOMContentLoaded', function() {
    // ========== تنظیمات ==========
    const POPUP_DELAY = 2000;           // ۲ ثانیه بعد از لود صفحه
    const TIMER_DURATION = 999 * 60 *60;     // ۱ ساعت (به ثانیه)
    const POPUP_STORAGE_KEY = 'ai_popup_closed';
    const POPUP_TIME_KEY = 'ai_popup_time';

    // ========== المنت‌ها ==========
    const popup = document.getElementById('aiPopup');
    const overlay = document.getElementById('aiPopupOverlay');
    const closeBtn = document.getElementById('aiPopupClose');
    const productsContainer = document.getElementById('aiPopupProducts');

    // ========== بررسی قبلاً بسته شده ==========
    const isClosed = localStorage.getItem(POPUP_STORAGE_KEY);
    const savedTime = localStorage.getItem(POPUP_TIME_KEY);
    let timerInterval = null;
    let remainingTime = TIMER_DURATION;

    // اگه قبلاً بسته شده بود یا تایم تموم شده بود، دیگه نشون نده
    // if (isClosed === 'true') {
    //     return;
    // }

    if (savedTime) {
        const elapsed = Math.floor((Date.now() - parseInt(savedTime)) / 1000);
        remainingTime = Math.max(0, TIMER_DURATION - elapsed);
        if (remainingTime <= 0) {
            // تایم تموم شده، پاپ‌آپ رو نشون نده
            return;
        }
    } else {
        localStorage.setItem(POPUP_TIME_KEY, Date.now().toString());
    }

    // ========== بارگذاری محصولات ==========
    async function loadPopupProducts() {
        productsContainer.innerHTML = `
            <div class="popup-loading">
                <div class="spinner-small"></div>
                <p>🤖 هوش مصنوعی در حال انتخاب...</p>
            </div>
        `;

        try {
            const response = await fetch('/one-target/backend/index.php?action=get-products&limit=50');
            const data = await response.json();

            if (data.success && data.products && data.products.length > 0) {
                const picks = selectSmartPicks(data.products);
                
                if (picks.length > 0) {
                    productsContainer.innerHTML = picks.map((p, i) => createPopupProduct(p, i)).join('');
                    
                    // کلیک روی محصولات
                    document.querySelectorAll('.popup-product-item').forEach(item => {
                        item.addEventListener('click', function() {
                            const id = this.dataset.productId;
                            if (id) window.location.href = `/one-target/product-detail.html?id=${id}`;
                        });
                    });
                } else {
                    productsContainer.innerHTML = `<p style="color:#666;font-size:13px;">محصولی برای پیشنهاد وجود ندارد</p>`;
                }
            } else {
                productsContainer.innerHTML = `<p style="color:#666;font-size:13px;">خطا در بارگذاری</p>`;
            }
        } catch (error) {
            console.error('Error loading popup products:', error);
            productsContainer.innerHTML = `<p style="color:#666;font-size:13px;">خطا در بارگذاری</p>`;
        }
    }

    // ========== الگوریتم انتخاب هوشمند ==========
    function selectSmartPicks(products) {
        return products
            .map(p => {
                let score = 0;
                if (p.is_best_seller) score += 40;
                if (p.is_new) score += 25;
                if (p.discount_percent) score += Math.min(p.discount_percent, 30);
                if (p.is_featured) score += 20;
                score += (p.views || 0) * 0.2;
                score += (p.rating_avg || 0) * 4;
                if (p.stock > 0) score += 10;
                return { ...p, score };
            })
            .sort((a, b) => b.score - a.score)
            .slice(0, 3);
    }

    // ========== ساخت محصول در پاپ‌آپ ==========
    function createPopupProduct(product, index) {
        const ranks = ['🥇', '🥈', '🥉'];
        const rankColors = ['gold', 'silver', 'bronze'];
        
        let discountText = '';
        if (product.discount_percent && product.discount_percent > 0) {
            discountText = `-${product.discount_percent}%`;
        } else if (product.is_best_seller) {
            discountText = '🔥 پرفروش';
        } else if (product.is_new) {
            discountText = '✨ جدید';
        } else {
            discountText = '⭐ پیشنهادی';
        }

        const oldPriceHtml = product.old_price && product.old_price > product.price
            ? `<span class="old-price">${Number(product.old_price).toLocaleString('fa-IR')} تومان</span>`
            : '';

        return `
            <div class="popup-product-item" data-product-id="${product.id}">
                <span class="rank ${rankColors[index]}">${ranks[index]}</span>
                <img src="${product.image || '/one-target/images/placeholder.jpg'}" alt="${product.name_fa}">
                <div class="info">
                    <div class="name">${product.name_fa}</div>
                    <div>
                        <span class="price">${Number(product.price).toLocaleString('fa-IR')} تومان</span>
                        ${oldPriceHtml}
                    </div>
                </div>
                <span class="tag">${discountText}</span>
            </div>
        `;
    }

    // ========== تایمر ==========
    function startTimer() {
        const hoursEl = document.getElementById('timerHours');
        const minutesEl = document.getElementById('timerMinutes');
        const secondsEl = document.getElementById('timerSeconds');

        // function updateTimer() {
        //     if (remainingTime <= 0) {
        //         clearInterval(timerInterval);
        //         document.querySelector('.ai-popup-timer').innerHTML = `
        //             <div style="color:#ff6b00;font-weight:bold;font-size:18px;">
        //                 ⏰ زمان تخفیف به پایان رسید!
        //             </div>
        //         `;
        //         return;
        //     }

        //     const h = Math.floor(remainingTime / 3600);
        //     const m = Math.floor((remainingTime % 3600) / 60);
        //     const s = remainingTime % 60;

        //     hoursEl.textContent = String(h).padStart(2, '0');
        //     minutesEl.textContent = String(m).padStart(2, '0');
        //     secondsEl.textContent = String(s).padStart(2, '0');

        //     remainingTime--;
        // }



        function updateTimer() {
    if (remainingTime <= 0) {
        clearInterval(timerInterval);
        document.querySelector('.ai-popup-timer').innerHTML = `
            <div style="color:#ff6b00;font-weight:bold;font-size:18px;">
                ⏰ زمان تخفیف به پایان رسید!
            </div>
        `;
        return;
    }

    const h = Math.floor(remainingTime / 3600);
    const m = Math.floor((remainingTime % 3600) / 60);
    const s = remainingTime % 60;

    // ✅ ترتیب جدید: اول ثانیه، بعد دقیقه، بعد ساعت
    secondsEl.textContent = String(s).padStart(2, '0');
    minutesEl.textContent = String(m).padStart(2, '0');
    hoursEl.textContent = String(h).padStart(2, '0');

    remainingTime--;
}

        updateTimer();
        timerInterval = setInterval(updateTimer, 1000);
    }

    // ========== نمایش پاپ‌آپ ==========
    function showPopup() {
        popup.classList.add('active');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';

        // بارگذاری محصولات
        loadPopupProducts();

        // تایمر
        startTimer();
    }

    // ========== بستن پاپ‌آپ ==========
    // function closePopup() {
    //     popup.classList.remove('active');
    //     overlay.classList.remove('active');
    //     document.body.style.overflow = '';
        
    //     // ذخیره در localStorage که کاربر بسته
    //     localStorage.setItem(POPUP_STORAGE_KEY, 'true');
    //     localStorage.setItem(POPUP_TIME_KEY, Date.now().toString());

    //     if (timerInterval) {
    //         clearInterval(timerInterval);
    //     }
    // }



function closePopup() {
    popup.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = 'auto';
    
    // ===== این دو خط رو کامنت کن یا حذف کن =====
    // localStorage.setItem(POPUP_STORAGE_KEY, 'true');
    // localStorage.setItem(POPUP_TIME_KEY, Date.now().toString());

    if (timerInterval) {
        clearInterval(timerInterval);
    }
}


    // ========== رویدادها ==========
    if (closeBtn) {
        closeBtn.addEventListener('click', closePopup);
    }

    if (overlay) {
        overlay.addEventListener('click', closePopup);
    }

    // ========== نمایش با تأخیر ==========
    setTimeout(() => {
        showPopup();
    }, POPUP_DELAY);
});