// js/dashboard.js
// توجه: API_URL، formatPrice، showMessage، apiCall از main.js میان

let currentUser = null;

async function loadUserProfile() {
    const data = await apiCall('get-user-profile');

    if (data.success) {
        currentUser = data.user;
        document.getElementById('userFullName').textContent = data.user.fullname;
        document.getElementById('userEmail').textContent = data.user.email;

        document.getElementById('profileFullname').value = data.user.fullname || '';
        document.getElementById('profileEmail').value = data.user.email || '';
        document.getElementById('profilePhone').value = data.user.phone || '';
        document.getElementById('profileAddress').value = data.user.address || '';

        // تاریخ عضویت اگر المنت وجود داشت
        const profileDate = document.getElementById('profileDate');
        if (profileDate && data.user.created_at) {
            profileDate.value = new Date(data.user.created_at).toLocaleDateString('fa-IR');
        }
    } else if (data.error === 'Please login') {
        window.location.href = 'index.html';
    }
}

async function updateProfile(fullname, phone, address) {
    const data = await apiCall('update-user-profile', 'POST', { fullname, phone, address });
    if (data.success) {
        showMessage('اطلاعات با موفقیت به‌روز شد');
        const userFullNameEl = document.getElementById('userFullName');
        if (userFullNameEl) userFullNameEl.textContent = fullname;
        const userNameEl = document.getElementById('userName');
        if (userNameEl) userNameEl.textContent = fullname;
    } else {
        showMessage(data.error || 'خطا در به‌روزرسانی', true);
    }
}

async function changePassword(currentPassword, newPassword) {
    const data = await apiCall('change-password', 'POST', {
        current_password: currentPassword,
        new_password: newPassword
    });
    if (data.success) {
        showMessage('رمز عبور با موفقیت تغییر کرد');
        document.getElementById('changePasswordForm').reset();
    } else {
        showMessage(data.error || 'خطا در تغییر رمز', true);
    }
}

// ========== سفارشات در داشبورد ==========
async function loadDashboardOrders() {
    const data = await apiCall('get-orders');
    const container = document.getElementById('ordersList');
    if (!container) return;

    if (data.success && data.orders && data.orders.length > 0) {
        container.innerHTML = data.orders.slice(0, 5).map(order => createOrderItem(order)).join('');
        container.querySelectorAll('.order-item').forEach(item => {
            item.addEventListener('click', () => {
                window.location.href = `orders.html?order=${item.dataset.orderId}`;
            });
        });
    } else {
        container.innerHTML = `
            <div class="empty-state-small">
                <p>شما هنوز سفارشی ثبت نکرده‌اید</p>
                <a href="products.html" class="btn-primary">مشاهده محصولات</a>
            </div>
        `;
    }
}

function createOrderItem(order) {
    const statusMap = {
        'pending': 'در انتظار پرداخت',
        'processing': 'در حال پردازش',
        'shipped': 'ارسال شده',
        'delivered': 'تحویل داده شده',
        'cancelled': 'لغو شده'
    };
    const statusClass = {
        'pending': 'status-pending',
        'processing': 'status-processing',
        'shipped': 'status-shipped',
        'delivered': 'status-delivered',
        'cancelled': 'status-cancelled'
    };

    return `
        <div class="order-item" data-order-id="${order.id}">
            <div class="order-header">
                <div>
                    <span class="order-number">#${order.order_number}</span>
                    <span class="order-date">${new Date(order.created_at).toLocaleDateString('fa-IR')}</span>
                </div>
                <span class="order-status ${statusClass[order.status] || ''}">${statusMap[order.status] || order.status}</span>
                <div class="order-total">${formatPrice(order.final_amount)} تومان</div>
            </div>
            <div class="order-items-count">${order.items?.length || 0} محصول</div>
        </div>
    `;
}

// ========== علاقه‌مندی‌ها در داشبورد ==========
async function loadDashboardWishlist() {
    const data = await apiCall('get-wishlist');
    const container = document.getElementById('wishlistProducts');
    if (!container) return;

    if (data.success && data.products && data.products.length > 0) {
        container.innerHTML = data.products.slice(0, 4).map(product => `
            <div class="wishlist-item" onclick="location.href='product-detail.html?id=${product.id}'" style="cursor:pointer">
                <div class="wishlist-item-image">
                    <img src="${product.image || 'images/placeholder.jpg'}" alt="${product.name_fa}">
                </div>
                <div class="wishlist-item-info">
                    <div class="wishlist-item-title">${product.name_fa}</div>
                    <div class="wishlist-item-price">${formatPrice(product.price)} تومان</div>
                    <div class="wishlist-item-actions">
                        <button class="move-to-cart-dash" data-product-id="${product.id}">➕ افزودن به سبد</button>
                        <button class="remove-wishlist-dash" data-product-id="${product.id}">🗑️ حذف</button>
                    </div>
                </div>
            </div>
        `).join('');

        container.querySelectorAll('.move-to-cart-dash').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const result = await apiCall('add-to-cart', 'POST', { product_id: btn.dataset.productId, quantity: 1 });
                if (result.success) {
                    showMessage('به سبد خرید اضافه شد');
                    updateCartCount();
                } else {
                    showMessage(result.error || 'خطا', true);
                }
            });
        });

        container.querySelectorAll('.remove-wishlist-dash').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const result = await apiCall('toggle-wishlist', 'POST', { product_id: btn.dataset.productId });
                if (result.success) {
                    showMessage('از علاقه‌مندی‌ها حذف شد');
                    await loadDashboardWishlist();
                    loadWishlistCount();
                }
            });
        });
    } else {
        container.innerHTML = `
            <div class="empty-state-small">
                <p>هنوز محصولی به علاقه‌مندی‌ها اضافه نکرده‌اید</p>
                <a href="products.html" class="btn-primary">مشاهده محصولات</a>
            </div>
        `;
    }
}

// ========== تب‌ها ==========
function setupTabs() {
    const tabs = document.querySelectorAll('.dashboard-nav a[data-tab]');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = tab.dataset.tab;

            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            contents.forEach(c => c.classList.remove('active'));

            const target = document.getElementById(`${tabId}Tab`);
            if (target) target.classList.add('active');

            if (tabId === 'orders') loadDashboardOrders();
            if (tabId === 'wishlist') loadDashboardWishlist();
        });
    });
}

function setupProfileForm() {
    const form = document.getElementById('profileForm');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fullname = document.getElementById('profileFullname').value.trim();
        const phone = document.getElementById('profilePhone').value.trim();
        const address = document.getElementById('profileAddress').value.trim();
        if (!fullname) { showMessage('نام الزامی است', true); return; }
        await updateProfile(fullname, phone, address);
    });
}

function setupPasswordForm() {
    const form = document.getElementById('changePasswordForm');
    if (!form) return;
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const current = document.getElementById('currentPassword').value;
        const newPass = document.getElementById('newPassword').value;
        const confirm = document.getElementById('confirmPassword').value;

        if (newPass !== confirm) { showMessage('رمز عبور جدید و تکرار آن مطابقت ندارند', true); return; }
        if (newPass.length < 6) { showMessage('رمز عبور جدید باید حداقل ۶ کاراکتر باشد', true); return; }

        await changePassword(current, newPass);
    });
}

function setupDashboardLogout() {
    const logoutBtn = document.getElementById('dashboardLogoutBtn');
    if (!logoutBtn) return;
    logoutBtn.addEventListener('click', async (e) => {
        e.preventDefault();
        await apiCall('logout');
        window.location.href = 'index.html';
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    await loadUserProfile();
    await loadDashboardOrders();
    setupTabs();
    setupProfileForm();
    setupPasswordForm();
    setupDashboardLogout();
});
