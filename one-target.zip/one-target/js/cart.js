// js/cart.js
// توجه: API_URL، formatPrice، showMessage، apiCall از main.js میان

let cartData = null;

async function loadCart() {
    const data = await apiCall('get-cart');

    if (data.success) {
        document.getElementById('loadingSpinner').style.display = 'none';
        if (data.items && data.items.length > 0) {
            cartData = data;
            displayCart(data);
            document.getElementById('cartContent').style.display = 'block';
            updateCartCount();
        } else {
            document.getElementById('emptyCart').style.display = 'block';
        }
    } else if (data.error === 'Please login') {
        document.getElementById('loadingSpinner').style.display = 'none';
        document.getElementById('emptyCart').style.display = 'block';
        document.getElementById('emptyCart').innerHTML = `
            <h3>برای مشاهده سبد خرید وارد شوید</h3>
            <p>لطفاً ابتدا وارد حساب کاربری خود شوید.</p>
            <button class="btn-primary" id="loginToCartBtn">ورود به حساب</button>
        `;
        document.getElementById('loginToCartBtn')?.addEventListener('click', () => showAuthModal());
    } else {
        document.getElementById('loadingSpinner').innerHTML = '<p class="error">خطا در بارگذاری سبد خرید</p>';
    }
}

function displayCart(data) {
    const container = document.getElementById('cartItemsList');
    container.innerHTML = data.items.map(item => `
        <div class="cart-item" data-cart-id="${item.cart_id}" data-product-id="${item.id}">
            <div class="product-col-cart">
                <div class="product-image">
                    <img src="${item.image || 'images/placeholder.jpg'}" alt="${item.name_fa}">
                </div>
                <div class="product-info-cart">
                    <h3><a href="product-detail.html?id=${item.id}">${item.name_fa}</a></h3>
                    <div class="product-brand">${item.brand || ''}</div>
                </div>
            </div>
            <div class="price-col-cart">${formatPrice(item.price)} تومان</div>
            <div class="quantity-col-cart">
                <div class="quantity-controls">
                    <button class="decrease-qty" data-cart-id="${item.cart_id}">-</button>
                    <input type="number" class="qty-input" data-cart-id="${item.cart_id}" value="${item.quantity}" min="1" max="${item.stock}">
                    <button class="increase-qty" data-cart-id="${item.cart_id}">+</button>
                </div>
            </div>
            <div class="total-col-cart">${formatPrice(item.total)} تومان</div>
            <div class="action-col-cart">
                <button class="remove-item-btn" data-cart-id="${item.cart_id}">🗑️</button>
            </div>
        </div>
    `).join('');

    updateSummary(data);
    attachCartEvents();
}

function updateSummary(data) {
    const subtotalEl = document.getElementById('summarySubtotal');
    const shippingEl = document.getElementById('summaryShipping');
    const totalEl = document.getElementById('summaryTotal');
    const freeShippingEl = document.getElementById('freeShippingInfo');

    if (subtotalEl) subtotalEl.textContent = formatPrice(data.subtotal) + ' تومان';
    if (shippingEl) shippingEl.textContent = data.shipping > 0 ? formatPrice(data.shipping) + ' تومان' : 'رایگان';
    if (totalEl) totalEl.textContent = formatPrice(data.total) + ' تومان';

    if (freeShippingEl) {
        if (data.subtotal >= 500000) {
            freeShippingEl.innerHTML = '<span>✓ ارسال رایگان برای این سفارش</span>';
            freeShippingEl.style.color = '#28a745';
        } else {
            const remaining = 500000 - data.subtotal;
            freeShippingEl.innerHTML = `<span>برای ارسال رایگان ${formatPrice(remaining)} تومان دیگر خرید کنید</span>`;
            freeShippingEl.style.color = '#aaa';
        }
    }
}

function attachCartEvents() {
    document.querySelectorAll('.decrease-qty').forEach(btn => {
        btn.addEventListener('click', async () => {
            const cartId = btn.dataset.cartId;
            const input = document.querySelector(`.qty-input[data-cart-id="${cartId}"]`);
            let newQty = parseInt(input.value) - 1;
            if (newQty >= 1) await updateCartQuantity(cartId, newQty);
        });
    });

    document.querySelectorAll('.increase-qty').forEach(btn => {
        btn.addEventListener('click', async () => {
            const cartId = btn.dataset.cartId;
            const input = document.querySelector(`.qty-input[data-cart-id="${cartId}"]`);
            const max = parseInt(input.max);
            let newQty = parseInt(input.value) + 1;
            if (newQty <= max) {
                await updateCartQuantity(cartId, newQty);
            } else {
                showMessage('موجودی کافی نیست', true);
            }
        });
    });

    document.querySelectorAll('.qty-input').forEach(input => {
        input.addEventListener('change', async () => {
            const cartId = input.dataset.cartId;
            let newQty = parseInt(input.value);
            const max = parseInt(input.max);
            if (isNaN(newQty) || newQty < 1) newQty = 1;
            if (newQty > max) {
                showMessage('موجودی کافی نیست', true);
                newQty = max;
            }
            input.value = newQty;
            await updateCartQuantity(cartId, newQty);
        });
    });

    document.querySelectorAll('.remove-item-btn').forEach(btn => {
        btn.addEventListener('click', async () => {
            const cartId = btn.dataset.cartId;
            if (confirm('آیا از حذف این محصول از سبد خرید مطمئن هستید؟')) {
                await removeFromCart(cartId);
            }
        });
    });
}

async function updateCartQuantity(cartId, quantity) {
    const result = await apiCall('update-cart', 'POST', { cart_id: cartId, quantity });
    if (result.success) {
        await loadCart();
    } else {
        showMessage(result.error || 'خطا در به‌روزرسانی', true);
    }
}

async function removeFromCart(cartId) {
    const result = await apiCall('remove-from-cart', 'POST', { cart_id: cartId });
    if (result.success) {
        showMessage('محصول از سبد خرید حذف شد');
        await loadCart();
        updateCartCount();
    } else {
        showMessage(result.error || 'خطا در حذف', true);
    }
}

function setupClearCart() {
    const clearBtn = document.getElementById('clearCartBtn');
    if (!clearBtn) return;
    clearBtn.addEventListener('click', async () => {
        if (confirm('آیا از حذف همه محصولات از سبد خرید مطمئن هستید؟')) {
            if (cartData && cartData.items) {
                for (const item of cartData.items) {
                    await apiCall('remove-from-cart', 'POST', { cart_id: item.cart_id });
                }
                await loadCart();
                updateCartCount();
                showMessage('سبد خرید خالی شد');
            }
        }
    });
}

function setupCheckout() {
    const checkoutBtn = document.getElementById('checkoutBtn');
    const modal = document.getElementById('checkoutModal');
    if (!checkoutBtn || !modal) return;

    checkoutBtn.addEventListener('click', async () => {
        await loadUserInfoForCheckout();
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    });

    const closeBtn = modal.querySelector('.modal-close');
    if (closeBtn) closeBtn.onclick = () => { modal.style.display = 'none'; document.body.style.overflow = 'auto'; };
    modal.onclick = (e) => { if (e.target === modal) { modal.style.display = 'none'; document.body.style.overflow = 'auto'; } };
}

async function loadUserInfoForCheckout() {
    const data = await apiCall('get-user-profile');
    if (data.success) {
        const receiverName = document.getElementById('receiverName');
        const receiverPhone = document.getElementById('receiverPhone');
        const shippingAddress = document.getElementById('shippingAddress');
        if (receiverName) receiverName.value = data.user.fullname || '';
        if (receiverPhone) receiverPhone.value = data.user.phone || '';
        if (shippingAddress) shippingAddress.value = data.user.address || '';
    }

    if (cartData) {
        const subtotalEl = document.getElementById('checkoutSubtotal');
        const shippingEl = document.getElementById('checkoutShipping');
        const totalEl = document.getElementById('checkoutTotal');
        if (subtotalEl) subtotalEl.textContent = formatPrice(cartData.subtotal) + ' تومان';
        if (shippingEl) shippingEl.textContent = cartData.shipping > 0 ? formatPrice(cartData.shipping) + ' تومان' : 'رایگان';
        if (totalEl) totalEl.textContent = formatPrice(cartData.total) + ' تومان';
    }
}

function setupOrderSubmit() {
    const form = document.getElementById('checkoutForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const receiverName = document.getElementById('receiverName').value.trim();
        const receiverPhone = document.getElementById('receiverPhone').value.trim();
        const shippingAddress = document.getElementById('shippingAddress').value.trim();
        const paymentMethod = document.getElementById('paymentMethod').value;

        if (!receiverName || !receiverPhone || !shippingAddress) {
            showMessage('لطفاً تمام فیلدهای الزامی را پر کنید', true);
            return;
        }

        const submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        submitBtn.textContent = 'در حال ثبت سفارش...';

        const result = await apiCall('create-order', 'POST', {
            receiver_name: receiverName,
            receiver_phone: receiverPhone,
            shipping_address: shippingAddress,
            payment_method: paymentMethod
        });

        if (result.success) {
            showOrderSuccess(result);
        } else {
            showMessage(result.error || 'خطا در ثبت سفارش', true);
            submitBtn.disabled = false;
            submitBtn.textContent = 'ثبت سفارش';
        }
    });
}

function showOrderSuccess(order) {
    const modal = document.getElementById('checkoutModal');
    const modalBody = modal.querySelector('.modal-body');

    modalBody.innerHTML = `
        <div class="success-message">
            <div class="checkmark">✓</div>
            <h3>سفارش شما با موفقیت ثبت شد!</h3>
            <p>شماره سفارش: <strong>${order.order_number}</strong></p>
            <p>مبلغ قابل پرداخت: <strong>${formatPrice(order.final_amount)} تومان</strong></p>
            <p>به زودی با شما تماس گرفته خواهد شد.</p>
            <button class="btn-primary" id="closeSuccessModal">متوجه شدم</button>
        </div>
    `;

    document.getElementById('closeSuccessModal').addEventListener('click', () => {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
        window.location.href = 'orders.html';
    });

    loadCart();
    updateCartCount();
}

document.addEventListener('DOMContentLoaded', () => {
    loadCart();
    setupClearCart();
    setupCheckout();
    setupOrderSubmit();
});
