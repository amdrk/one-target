// js/detail.js
// توجه: API_URL، formatPrice، showMessage، apiCall از main.js میان

let currentProduct = null;
let currentProductId = null;
let currentImages = [];

function getProductIdFromUrl() {
    return new URLSearchParams(window.location.search).get('id');
}

async function loadProductDetail() {
    const productId = getProductIdFromUrl();
    if (!productId) { window.location.href = 'products.html'; return; }
    currentProductId = productId;

    // ✅ اصلاح: استفاده از apiCall به جای fetch مستقیم
    const data = await apiCall(`get-product&id=${productId}`);

    if (data.success) {
        currentProduct = data.product;
        currentImages = [data.product.image, data.product.image2, data.product.image3].filter(Boolean);

        displayProductInfo(data);
        displaySpecs(data.specs);
        displayReviews(data.reviews);
        displayRelatedProducts(data.related_products);
        setupWishlistButton(data.in_wishlist);

        document.getElementById('loadingSpinner').style.display = 'none';
        document.getElementById('productContent').style.display = 'block';
    } else {
        document.getElementById('loadingSpinner').innerHTML = '<p class="error">محصول مورد نظر یافت نشد</p>';
    }
}

function displayProductInfo(data) {
    const product = data.product;

    document.title = `${product.name_fa} | One Target`;
    document.getElementById('productTitle').textContent = product.name_fa;
    document.getElementById('productNameBreadcrumb').textContent = product.name_fa;

    const categoryLink = document.getElementById('categoryLink');
    if (categoryLink) {
        categoryLink.href = `products.html?category=${product.category_slug}`;
        categoryLink.textContent = product.category_name || 'محصولات';
    }

    const mainImg = document.getElementById('mainProductImage');
    if (mainImg) {
        mainImg.src = currentImages[0] || 'images/placeholder.jpg';
        mainImg.alt = product.name_fa;
    }

    const thumbnailList = document.getElementById('thumbnailList');
    if (thumbnailList && currentImages.length > 1) {
        thumbnailList.innerHTML = currentImages.map((img, i) => `
            <img src="${img}" alt="تصویر ${i + 1}" data-index="${i}" class="${i === 0 ? 'active' : ''}">
        `).join('');
        thumbnailList.querySelectorAll('img').forEach((thumb, idx) => {
            thumb.addEventListener('click', () => {
                mainImg.src = currentImages[idx];
                thumbnailList.querySelectorAll('img').forEach(t => t.classList.remove('active'));
                thumb.classList.add('active');
            });
        });
    }

    const rating = product.rating_avg || 0;
    let starsHtml = '';
    for (let i = 1; i <= 5; i++) {
        starsHtml += i <= Math.floor(rating) ? '⭐' : (i === Math.floor(rating) + 1 && rating % 1 >= 0.5 ? '½' : '☆');
    }
    const productStars = document.getElementById('productStars');
    const productRating = document.getElementById('productRating');
    const productReviewCount = document.getElementById('productReviewCount');
    if (productStars) productStars.innerHTML = starsHtml;
    if (productRating) productRating.textContent = Number(rating).toFixed(1);
    if (productReviewCount) productReviewCount.textContent = `(${product.review_count || 0} نظر)`;

    const productBrand = document.getElementById('productBrand');
    const productWarranty = document.getElementById('productWarranty');
    if (productBrand) productBrand.textContent = product.brand || '—';
    if (productWarranty) productWarranty.textContent = product.warranty || '—';

    const stockSpan = document.getElementById('productStock');
    if (stockSpan) {
        if (product.stock > 0) {
            stockSpan.innerHTML = `✓ موجود در انبار (${product.stock} عدد)`;
            stockSpan.className = 'product-stock in-stock';
        } else {
            stockSpan.innerHTML = '✗ ناموجود';
            stockSpan.className = 'product-stock out-stock';
            const addBtn = document.getElementById('addToCartBtn');
            if (addBtn) { addBtn.disabled = true; addBtn.textContent = 'ناموجود'; }
        }
    }

    const productPrice = document.getElementById('productPrice');
    const productOldPrice = document.getElementById('productOldPrice');
    const discountBadge = document.getElementById('discountBadge');
    if (productPrice) productPrice.textContent = formatPrice(product.price) + ' تومان';
    if (productOldPrice && product.old_price && product.old_price > product.price) {
        productOldPrice.textContent = formatPrice(product.old_price) + ' تومان';
        if (discountBadge) {
            const discount = Math.round(((product.old_price - product.price) / product.old_price) * 100);
            discountBadge.textContent = `${discount}٪ تخفیف`;
        }
    } else {
        if (productOldPrice) productOldPrice.textContent = '';
        if (discountBadge) discountBadge.textContent = '';
    }

    const productShortDesc = document.getElementById('productShortDesc');
    if (productShortDesc) productShortDesc.textContent = product.short_desc || (product.description?.substring(0, 150)) || '';

    const productDescription = document.getElementById('productDescription');
    if (productDescription) productDescription.innerHTML = product.description || 'توضیحاتی برای این محصول ثبت نشده است.';
}

function displaySpecs(specs) {
    const specsTable = document.getElementById('specsTable');
    if (!specsTable) return;
    if (!specs || specs.length === 0) {
        specsTable.innerHTML = '<tr><td colspan="2">مشخصات فنی برای این محصول ثبت نشده است.</td></tr>';
        return;
    }
    specsTable.innerHTML = specs.map(spec => `
        <tr><td>${spec.spec_name}</td><td>${spec.spec_value}</td></tr>
    `).join('');
}

function displayReviews(reviews) {
    const container = document.getElementById('reviewsSection');
    if (!container) return;

    if (!reviews || reviews.length === 0) {
        container.innerHTML = `
            <div class="reviews-header">
                <h3>نظرات کاربران</h3>
                <button class="write-review-btn" id="writeReviewBtn">ثبت نظر</button>
            </div>
            <div class="no-reviews">هنوز نظری ثبت نشده است. اولین نفری باشید که نظر می‌دهید!</div>
        `;
        document.getElementById('writeReviewBtn')?.addEventListener('click', showReviewModal);
        return;
    }

    const total = reviews.length;
    const avg = reviews.reduce((s, r) => s + r.rating, 0) / total;
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(r => { distribution[r.rating] = (distribution[r.rating] || 0) + 1; });

    let starsHtml = '';
    for (let i = 1; i <= 5; i++) {
        starsHtml += i <= Math.floor(avg) ? '⭐' : (i === Math.floor(avg) + 1 && avg % 1 >= 0.5 ? '½' : '☆');
    }

    let barsHtml = '';
    for (let i = 5; i >= 1; i--) {
        const count = distribution[i] || 0;
        const percent = total > 0 ? (count / total) * 100 : 0;
        barsHtml += `
            <div class="rating-bar-item">
                <span class="star-label">${i} ستاره</span>
                <div class="bar"><div class="bar-fill" style="width:${percent}%"></div></div>
                <span class="count">${count}</span>
            </div>
        `;
    }

    container.innerHTML = `
        <div class="reviews-header">
            <h3>نظرات کاربران</h3>
            <button class="write-review-btn" id="writeReviewBtn">ثبت نظر</button>
        </div>
        <div class="reviews-summary">
            <div class="rating-summary">
                <div class="big-rating">${avg.toFixed(1)}</div>
                <div class="stars">${starsHtml}</div>
                <div>${total} نظر</div>
            </div>
            <div class="rating-bars">${barsHtml}</div>
        </div>
        <div class="reviews-list">
            ${reviews.map(review => `
                <div class="review-item">
                    <div class="review-header">
                        <span class="reviewer-name">${review.fullname}</span>
                        <div class="review-stars">${'⭐'.repeat(review.rating)}${'☆'.repeat(5 - review.rating)}</div>
                        <span class="review-date">${new Date(review.created_at).toLocaleDateString('fa-IR')}</span>
                    </div>
                    <div class="review-comment">${review.comment}</div>
                </div>
            `).join('')}
        </div>
    `;
    document.getElementById('writeReviewBtn')?.addEventListener('click', showReviewModal);
}

function displayRelatedProducts(products) {
    const container = document.getElementById('relatedProducts');
    if (!container || !products || products.length === 0) return;

    container.innerHTML = products.map(p => `
        <div class="product-card" onclick="location.href='product-detail.html?id=${p.id}'" style="cursor:pointer">
            <div class="product-image">
                <img src="${p.image || 'images/placeholder.jpg'}" alt="${p.name_fa}" loading="lazy">
            </div>
            <div class="product-info">
                <h3 class="product-title">${p.name_fa}</h3>
                <div class="product-price">
                    <span class="current-price">${formatPrice(p.price)} تومان</span>
                </div>
            </div>
        </div>
    `).join('');
}

function setupWishlistButton(inWishlist) {
    const btn = document.getElementById('wishlistBtn');
    if (!btn) return;

    const update = () => {
        btn.innerHTML = inWishlist ? '❤️ حذف از علاقه‌مندی‌ها' : '🤍 علاقه‌مندی';
    };
    update();

    btn.addEventListener('click', async () => {
        const result = await apiCall('toggle-wishlist', 'POST', { product_id: currentProductId });
        if (result.success) {
            inWishlist = result.action === 'added';
            update();
            showMessage(result.message);
            loadWishlistCount();
        } else if (result.error === 'Please login') {
            showAuthModal();
        }
    });
}

function setupQuantityControls() {
    const decreaseBtn = document.getElementById('decreaseQty');
    const increaseBtn = document.getElementById('increaseQty');
    const quantityInput = document.getElementById('productQuantity');
    if (!decreaseBtn || !increaseBtn || !quantityInput) return;

    decreaseBtn.addEventListener('click', () => {
        let val = parseInt(quantityInput.value);
        if (val > 1) quantityInput.value = val - 1;
    });

    increaseBtn.addEventListener('click', () => {
        let val = parseInt(quantityInput.value);
        if (currentProduct && val < currentProduct.stock) {
            quantityInput.value = val + 1;
        } else {
            showMessage('موجودی کافی نیست', true);
        }
    });
}

function setupAddToCart() {
    const addBtn = document.getElementById('addToCartBtn');
    if (!addBtn) return;
    addBtn.addEventListener('click', async () => {
        const quantity = parseInt(document.getElementById('productQuantity').value) || 1;
        const result = await apiCall('add-to-cart', 'POST', {
            product_id: currentProductId,
            quantity: quantity
        });
        if (result.success) {
            showMessage(`${quantity} عدد به سبد خرید اضافه شد`);
            updateCartCount();
        } else if (result.error === 'Please login') {
            showAuthModal();
        } else {
            showMessage(result.error || 'خطا در افزودن به سبد خرید', true);
        }
    });
}

function showReviewModal() {
    apiCall('check-auth').then(data => {
        if (!data.logged_in) { showAuthModal(); return; }
        const modal = document.getElementById('reviewModal');
        if (!modal) {
            showMessage('فرم ثبت نظر در این صفحه موجود نیست', true);
            return;
        }
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';

        const closeBtn = document.getElementById('closeReviewModal');
        if (closeBtn) closeBtn.onclick = () => { modal.style.display = 'none'; document.body.style.overflow = 'auto'; };
        modal.onclick = (e) => { if (e.target === modal) { modal.style.display = 'none'; document.body.style.overflow = 'auto'; } };
    });
}

function setupReviewForm() {
    const form = document.getElementById('reviewForm');
    if (!form) return;
    form.onsubmit = async (e) => {
        e.preventDefault();
        const rating = parseInt(document.getElementById('reviewRating')?.value || 0);
        const comment = document.getElementById('reviewComment')?.value.trim();

        if (!rating) { showMessage('لطفاً امتیاز خود را مشخص کنید', true); return; }
        if (!comment) { showMessage('لطفاً نظر خود را بنویسید', true); return; }

        const result = await apiCall('add-review', 'POST', {
            product_id: currentProductId,
            rating,
            comment
        });

        if (result.success) {
            showMessage('نظر شما با موفقیت ثبت شد و پس از تأیید نمایش داده می‌شود');
            document.getElementById('reviewModal').style.display = 'none';
            document.body.style.overflow = 'auto';
            form.reset();
        } else {
            showMessage(result.error || 'خطا در ثبت نظر', true);
        }
    };
}

function setupTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabPanes = document.querySelectorAll('.tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            tabPanes.forEach(p => p.classList.remove('active'));
            const target = document.getElementById(`${btn.dataset.tab}Tab`);
            if (target) target.classList.add('active');
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadProductDetail();
    setupQuantityControls();
    setupAddToCart();
    setupTabs();
    setupReviewForm();
});
