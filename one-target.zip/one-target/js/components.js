// js/components.js

let headerLoaded = false;
let footerLoaded = false;

async function loadHeader() {
    if (headerLoaded) return;
    const headerPlaceholder = document.getElementById('header-placeholder');
    if (!headerPlaceholder || headerPlaceholder.innerHTML.trim()) return;

    try {
        const response = await fetch('components/header.html');
        if (!response.ok) return;
        headerPlaceholder.innerHTML = await response.text();
        headerLoaded = true;

        setTimeout(() => {
            attachHeaderEvents();
            if (typeof checkAuth === 'function') checkAuth();
            if (typeof updateCartCount === 'function') updateCartCount();
            if (typeof loadWishlistCount === 'function') loadWishlistCount();
            if (typeof setupAuthModal === 'function') setupAuthModal();
        }, 100);
    } catch (e) {
        console.error('Error loading header:', e);
    }
}

async function loadFooter() {
    if (footerLoaded) return;
    const footerPlaceholder = document.getElementById('footer-placeholder');
    if (!footerPlaceholder || footerPlaceholder.innerHTML.trim()) return;

    try {
        const response = await fetch('components/footer.html');
        if (!response.ok) return;
        footerPlaceholder.innerHTML = await response.text();
        footerLoaded = true;

        setTimeout(() => {
            if (typeof loadFooterCategories === 'function') loadFooterCategories();
        }, 100);
    } catch (e) {
        console.error('Error loading footer:', e);
    }
}

function attachHeaderEvents() {
    // ========== جستجو ==========
    const searchBtn = document.getElementById('searchBtn');
    const searchInput = document.getElementById('searchInput');

    if (searchBtn && searchInput) {
        searchBtn.onclick = () => {
            const query = searchInput.value.trim();
            if (query) window.location.href = `products.html?search=${encodeURIComponent(query)}`;
        };
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                const query = searchInput.value.trim();
                if (query) window.location.href = `products.html?search=${encodeURIComponent(query)}`;
            }
        });
    }

    // ========== پنل کاربری (اصلاح شده - با چک دقیق) ==========
    const userPanelLink = document.getElementById('userPanelLink');
    if (userPanelLink) {
        userPanelLink.addEventListener('click', async (e) => {
            e.preventDefault();
            
            try {
                if (typeof apiCall !== 'function') {
                    console.error('apiCall is not defined');
                    window.location.href = 'index.html';
                    return;
                }
                
                const authData = await apiCall('check-auth');
                console.log('📊 Auth Data:', authData); // برای دیباگ
                
                if (!authData.logged_in) {
                    if (typeof showAuthModal === 'function') {
                        showAuthModal();
                    } else {
                        window.location.href = 'index.html';
                    }
                    return;
                }
                
                // ✅ بررسی دقیق: فقط اگه is_admin == 1 باشه، به پنل ادمین بره
                if (authData.is_admin == 1) {
                    window.location.href = 'admin/dashboard.html';
                } else {
                    window.location.href = 'dashboard.html';
                }
            } catch (error) {
                console.error('Error checking auth:', error);
                window.location.href = 'index.html';
            }
        });
    }

    // ========== خروج ==========
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            if (typeof logoutUser === 'function') {
                await logoutUser();
            } else {
                try {
                    await apiCall('logout');
                    window.location.reload();
                } catch (error) {
                    console.error('Logout error:', error);
                    window.location.reload();
                }
            }
        });
    }

    // ========== دکمه کاربر (در هدر) ==========
    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
        userBtn.addEventListener('click', async () => {
            const userNameSpan = document.getElementById('userName');
            
            if (userNameSpan && userNameSpan.textContent === 'ورود') {
                if (typeof showAuthModal === 'function') {
                    showAuthModal();
                }
                return;
            }
            
            try {
                if (typeof apiCall !== 'function') {
                    window.location.href = 'dashboard.html';
                    return;
                }
                
                const authData = await apiCall('check-auth');
                if (authData.is_admin == 1) {
                    window.location.href = 'admin/dashboard.html';
                } else {
                    window.location.href = 'dashboard.html';
                }
            } catch (error) {
                console.error('Error:', error);
                window.location.href = 'dashboard.html';
            }
        });
    }
}

async function loadFooterCategories() {
    const container = document.getElementById('footerCategories');
    if (!container || container.innerHTML.trim()) return;

    try {
        const apiUrl = typeof API_URL !== 'undefined' ? API_URL : '/one-target/backend/index.php';
        const response = await fetch(`${apiUrl}?action=get-categories`);
        const data = await response.json();
        if (data.success && data.categories) {
            container.innerHTML = data.categories.slice(0, 6).map(cat =>
                `<li><a href="products.html?category=${cat.slug}">${cat.name}</a></li>`
            ).join('');
        }
    } catch (e) {
        console.error('Error loading footer categories:', e);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadHeader();
    loadFooter();
});