// ========== products.js ==========
// توجه: API_URL ، formatPrice ، showMessage و apiCall از main.js میان
// این فایل فقط منطق صفحه محصولات رو داره

// ========== وضعیت فیلترها ==========
let currentFilters = {
    page: 1,
    sort: 'newest',
    category: [],
    search: null,
    minPrice: null,
    maxPrice: null,
    brand: [],
    inStockOnly: false,
    rating: null,
    featured: null
};

let totalPages = 1;

// ========== به‌روزرسانی شمارنده فیلترها ==========
function updateFilterCount() {
    let count = 0;
    if (currentFilters.category.length > 0) count++;
    if (currentFilters.minPrice || currentFilters.maxPrice) count++;
    if (currentFilters.brand.length > 0) count++;
    if (currentFilters.inStockOnly) count++;
    if (currentFilters.rating) count++;

    const span = document.getElementById('filterCount');
    if (span) span.textContent = count;
}

// ========== خواندن پارامترهای URL ==========
function getUrlParams() {
    const params = new URLSearchParams(window.location.search);
    const categoryParam = params.get('category');
    currentFilters.category = categoryParam ? [categoryParam] : [];
    currentFilters.search = params.get('search') || null;
    currentFilters.sort = params.get('sort') || 'newest';
    currentFilters.featured = params.get('featured') || null;
}

// ========== بستن سایدبار فیلتر ==========
function closeFilterSidebar() {
    const sidebar = document.getElementById('filterSidebar');
    const overlay = document.getElementById('filterOverlay');
    if (sidebar) sidebar.classList.remove('open');
    if (overlay) overlay.classList.remove('active');
    document.body.style.overflow = 'auto';
}

// ========== بارگذاری محصولات ==========
async function loadProducts() {
    const container = document.getElementById('productsGrid');
    if (!container) return;

    container.innerHTML = '<div class="loading-spinner"><div class="spinner"></div><p>در حال بارگذاری محصولات...</p></div>';

    // ✅ ارسال همه فیلترها به سرور (نه client-side)
    let url = `${API_URL}?action=get-products&page=${currentFilters.page}&sort=${currentFilters.sort}&limit=12`;
    if (currentFilters.category.length > 0) url += `&category=${encodeURIComponent(currentFilters.category.join(','))}`;
    if (currentFilters.search)   url += `&search=${encodeURIComponent(currentFilters.search)}`;
    if (currentFilters.minPrice) url += `&min_price=${currentFilters.minPrice}`;
    if (currentFilters.maxPrice) url += `&max_price=${currentFilters.maxPrice}`;
    if (currentFilters.brand.length > 0) url += `&brand=${encodeURIComponent(currentFilters.brand.join(','))}`;
    if (currentFilters.inStockOnly) url += `&in_stock=1`;
    if (currentFilters.rating)   url += `&min_rating=${currentFilters.rating}`;
    if (currentFilters.featured) url += `&featured=1`;

    try {
        const response = await fetch(url, { credentials: 'same-origin' });
        const data = await response.json();

        if (data.success && data.products && data.products.length > 0) {
            container.innerHTML = data.products.map(p => createProductCard(p)).join('');
            attachProductCardEvents();

            const countSpan = document.getElementById('productsCount');
            if (countSpan) {
                countSpan.textContent = `نمایش ${data.products.length} از ${data.total} محصول`;
            }

            totalPages = data.total_pages || 1;
            renderPagination();
        } else {
            container.innerHTML = '<div class="no-products">😞 محصولی با این مشخصات یافت نشد</div>';
            const pag = document.getElementById('pagination');
            if (pag) pag.innerHTML = '';
            const countSpan = document.getElementById('productsCount');
            if (countSpan) countSpan.textContent = '';
        }
    } catch (error) {
        console.error('loadProducts error:', error);
        container.innerHTML = '<div class="no-products">❌ خطا در ارتباط با سرور</div>';
    }
}

// ========== کارت محصول ==========
function createProductCard(product) {
    const discountPercent = product.discount_percent ?
        `<span class="product-badge discount">-${product.discount_percent}%</span>` : '';
    const newBadge = product.is_new ?
        `<span class="product-badge new">جدید</span>` : '';
    const bestSellerBadge = product.is_best_seller ?
        `<span class="product-badge best-seller">پرفروش</span>` : '';
    const oldPriceHtml = product.old_price && product.old_price > product.price ?
        `<span class="old-price">${formatPrice(product.old_price)} تومان</span>` : '';

    let starsHtml = '';
    const rating = product.rating_avg || 0;
    for (let i = 1; i <= 5; i++) {
        starsHtml += i <= rating ? '⭐' : '☆';
    }

    return `
        <div class="product-card" data-product-id="${product.id}">
            <div class="product-image">
                <img src="${product.image || 'images/placeholder.jpg'}" alt="${product.name_fa}" loading="lazy">
                <div class="product-badges">
                    ${discountPercent}${newBadge}${bestSellerBadge}
                </div>
                <button class="wishlist-btn-card ${product.in_wishlist ? 'active' : ''}" data-product-id="${product.id}">
                    ${product.in_wishlist ? '❤️' : '🤍'}
                </button>
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name_fa}</h3>
                <div class="product-rating">
                    <div class="stars">${starsHtml}</div>
                    <span class="rating-count">(${product.review_count || 0})</span>
                </div>
                <div class="product-price-row">
                    <span class="current-price">${formatPrice(product.price)} تومان</span>
                    ${oldPriceHtml}
                </div>
                <button class="add-to-cart-btn" data-product-id="${product.id}">
                    🛒 افزودن به سبد خرید
                </button>
            </div>
        </div>
    `;
}

function attachProductCardEvents() {
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const result = await apiCall('add-to-cart', 'POST', { product_id: btn.dataset.productId, quantity: 1 });
            if (result.success) {
                showMessage('✓ به سبد خرید اضافه شد');
                updateCartCount();
            } else if (result.error === 'Please login') {
                showMessage('لطفاً ابتدا وارد شوید', true);
                showAuthModal();
            } else {
                showMessage(result.error || 'خطا', true);
            }
        });
    });

    document.querySelectorAll('.wishlist-btn-card').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const result = await apiCall('toggle-wishlist', 'POST', { product_id: btn.dataset.productId });
            if (result.success) {
                const isAdded = result.action === 'added';
                btn.classList.toggle('active', isAdded);
                btn.textContent = isAdded ? '❤️' : '🤍';
                showMessage(result.message);
                loadWishlistCount();
            } else if (result.error === 'Please login') {
                showMessage('لطفاً ابتدا وارد شوید', true);
                showAuthModal();
            }
        });
    });

    document.querySelectorAll('.product-card').forEach(card => {
        card.addEventListener('click', (e) => {
            if (!e.target.closest('.add-to-cart-btn') && !e.target.closest('.wishlist-btn-card')) {
                window.location.href = `product-detail.html?id=${card.dataset.productId}`;
            }
        });
    });
}

// ========== پیجینیشن ==========
function renderPagination() {
    const container = document.getElementById('pagination');
    if (!container) return;
    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }

    let html = '';
    for (let i = 1; i <= totalPages; i++) {
        html += `<button class="page-btn ${i === currentFilters.page ? 'active' : ''}" data-page="${i}">${i}</button>`;
    }
    container.innerHTML = html;

    container.querySelectorAll('.page-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            currentFilters.page = parseInt(btn.dataset.page);
            loadProducts();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });
}

// ========== بارگذاری فیلترها ==========
async function loadFilters() {
    // دسته‌بندی‌ها از سرور
    const catData = await apiCall('get-categories');
    if (catData.success && catData.categories) {
        const categoryList = document.getElementById('categoryFilterList');
        if (categoryList) {
            categoryList.innerHTML = catData.categories.map(cat => `
                <li>
                    <label>
                        <input type="checkbox" value="${cat.slug}" class="category-filter"
                               ${currentFilters.category.includes(cat.slug) ? 'checked' : ''}>
                        <span>${cat.name}</span>
                        <span class="count">(${cat.product_count || 0})</span>
                    </label>
                </li>
            `).join('');

            categoryList.querySelectorAll('.category-filter').forEach(cb => {
                cb.addEventListener('change', () => {
                    const checked = Array.from(categoryList.querySelectorAll('.category-filter:checked'));
                    currentFilters.category = checked.map(c => c.value);
                    currentFilters.page = 1;
                    updateFilterCount();
                    loadProducts();
                });
            });
        }
    }

    // برندها
    const brandList = document.getElementById('brandFilterList');
    if (brandList) {
        const brands = ['Intel', 'AMD', 'NVIDIA', 'ASUS', 'MSI', 'Gigabyte', 'Corsair', 'Samsung', 'Logitech', 'Kingston'];
        brandList.innerHTML = brands.map(brand => `
            <li>
                <label>
                    <input type="checkbox" value="${brand}" class="brand-filter"
                           ${currentFilters.brand.includes(brand) ? 'checked' : ''}>
                    <span>${brand}</span>
                </label>
            </li>
        `).join('');

        brandList.querySelectorAll('.brand-filter').forEach(cb => {
            cb.addEventListener('change', () => {
                const checked = Array.from(brandList.querySelectorAll('.brand-filter:checked'));
                currentFilters.brand = checked.map(c => c.value);
                currentFilters.page = 1;
                updateFilterCount();
                loadProducts();
            });
        });
    }

    // امتیاز
    const ratingList = document.getElementById('ratingFilterList');
    if (ratingList) {
        const ratings = [
            { value: 5, stars: '⭐⭐⭐⭐⭐' },
            { value: 4, stars: '⭐⭐⭐⭐☆' },
            { value: 3, stars: '⭐⭐⭐☆☆' },
            { value: 2, stars: '⭐⭐☆☆☆' },
            { value: 1, stars: '⭐☆☆☆☆' }
        ];
        ratingList.innerHTML = ratings.map(r => `
            <label class="rating-option">
                <input type="radio" name="rating" value="${r.value}" class="rating-filter"
                       ${currentFilters.rating == r.value ? 'checked' : ''}>
                <span class="rating-stars">${r.stars}</span>
                <span>و بالاتر</span>
            </label>
        `).join('');

        ratingList.querySelectorAll('.rating-filter').forEach(rb => {
            rb.addEventListener('change', () => {
                currentFilters.rating = rb.value;
                currentFilters.page = 1;
                updateFilterCount();
                loadProducts();
            });
        });
    }

    // موجودی
    const inStockCb = document.getElementById('inStockOnly');
    if (inStockCb) {
        inStockCb.checked = currentFilters.inStockOnly;
        inStockCb.addEventListener('change', () => {
            currentFilters.inStockOnly = inStockCb.checked;
            currentFilters.page = 1;
            updateFilterCount();
            loadProducts();
        });
    }
}

// ========== فیلتر قیمت ==========
function setupPriceFilter() {
    const applyBtn = document.getElementById('applyPriceFilter');
    if (!applyBtn) return;
    applyBtn.addEventListener('click', () => {
        const minInput = document.getElementById('minPrice');
        const maxInput = document.getElementById('maxPrice');
        currentFilters.minPrice = minInput?.value ? parseInt(minInput.value.replace(/,/g, '')) : null;
        currentFilters.maxPrice = maxInput?.value ? parseInt(maxInput.value.replace(/,/g, '')) : null;
        currentFilters.page = 1;
        updateFilterCount();
        loadProducts();
        closeFilterSidebar();
    });
}

// ========== پاک کردن فیلترها ==========
function setupClearFilters() {
    const clearBtn = document.getElementById('clearAllFilters');
    if (!clearBtn) return;
    clearBtn.addEventListener('click', () => {
        currentFilters = {
            page: 1,
            sort: 'newest',
            category: [],
            search: null,
            minPrice: null,
            maxPrice: null,
            brand: [],
            inStockOnly: false,
            rating: null,
            featured: null
        };

        document.querySelectorAll('.category-filter, .brand-filter').forEach(cb => cb.checked = false);
        document.querySelectorAll('.rating-filter').forEach(rb => rb.checked = false);
        const inStockCb = document.getElementById('inStockOnly');
        if (inStockCb) inStockCb.checked = false;
        const minInput = document.getElementById('minPrice');
        const maxInput = document.getElementById('maxPrice');
        if (minInput) minInput.value = '';
        if (maxInput) maxInput.value = '';
        const sortSelect = document.getElementById('sortSelect');
        if (sortSelect) sortSelect.value = 'newest';

        updateFilterCount();
        loadProducts();
        closeFilterSidebar();
        showMessage('همه فیلترها حذف شدند');
    });
}

// ========== مرتب‌سازی ==========
function setupSort() {
    const sortSelect = document.getElementById('sortSelect');
    if (!sortSelect) return;
    sortSelect.value = currentFilters.sort;
    sortSelect.addEventListener('change', () => {
        currentFilters.sort = sortSelect.value;
        currentFilters.page = 1;
        loadProducts();
    });
}

// ========== باز/بسته شدن بخش‌های فیلتر ==========
function setupCollapsibleFilters() {
    document.querySelectorAll('.filter-section .filter-title').forEach(title => {
        title.addEventListener('click', (e) => {
            e.stopPropagation();
            title.closest('.filter-section').classList.toggle('collapsed');
        });
    });
}

// ========== راه‌اندازی سایدبار فیلتر ==========
function setupFilterSidebar() {
    const toggleBtn = document.getElementById('filterToggleBtn');
    const sidebar = document.getElementById('filterSidebar');
    const overlay = document.getElementById('filterOverlay');
    const closeBtn = document.getElementById('closeFilterBtn');

    if (toggleBtn) {
        toggleBtn.onclick = () => {
            sidebar.classList.add('open');
            overlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        };
    }
    if (closeBtn) closeBtn.onclick = closeFilterSidebar;
    if (overlay) overlay.onclick = closeFilterSidebar;
}

// ========== اجرا ==========
document.addEventListener('DOMContentLoaded', () => {
    getUrlParams();
    setupFilterSidebar();
    loadFilters();
    loadProducts();
    setupPriceFilter();
    setupSort();
    setupClearFilters();
    setupCollapsibleFilters();
    updateFilterCount();
});
