// ========== تنظیمات ==========
const API_URL = '/one-target/backend/index.php';

// ========== توابع کمکی ==========
function formatPrice(price) {
    return Number(price).toLocaleString('fa-IR');
}

function showMessage(message, isError = false) {
    // جلوگیری از نمایش چندتایی همزمان
    const existing = document.querySelector('.site-toast');
    if (existing) existing.remove();

    const msgDiv = document.createElement('div');
    msgDiv.className = 'site-toast';
    msgDiv.textContent = message;
    msgDiv.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 12px 24px;
        background: ${isError ? '#dc3545' : '#28a745'};
        color: white;
        border-radius: 8px;
        z-index: 10000;
        font-size: 14px;
        font-family: inherit;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        transition: opacity 0.3s;
    `;
    document.body.appendChild(msgDiv);
    setTimeout(() => {
        msgDiv.style.opacity = '0';
        setTimeout(() => msgDiv.remove(), 300);
    }, 2700);
}

// ========== API Call (باگ fetch POST برطرف شد) ==========
async function apiCall(action, method = 'GET', data = null) {
    const url = `${API_URL}?action=${action}`;
    const options = {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin'
    };
    if (data && method === 'POST') {
        options.body = JSON.stringify(data);
    }

    try {
        // ✅ اصلاح: options به fetch پاس داده می‌شه
        const response = await fetch(url, options);
        return await response.json();
    } catch (error) {
        console.error('API Error:', error);
        return { success: false, error: 'خطا در ارتباط با سرور' };
    }
}

// ========== محصولات ویژه (صفحه اصلی) ==========
async function loadFeaturedProducts() {
    const container = document.getElementById('featuredProducts');
    if (!container) return;

    const data = await apiCall('get-featured-products');
    if (data.success && data.products && data.products.length > 0) {
        container.innerHTML = data.products.map(p => createProductCard(p)).join('');
        attachProductEvents();
    } else {
        container.innerHTML = '<p class="no-products">محصولی یافت نشد</p>';
    }
}

async function loadNewProducts() {
    const container = document.getElementById('newProducts');
    if (!container) return;
    const data = await apiCall('get-new-products');
    if (data.success && data.products && data.products.length > 0) {
        container.innerHTML = data.products.map(p => createProductCard(p)).join('');
        attachProductEvents();
    }
}

async function loadBestSellers() {
    const container = document.getElementById('bestSellers');
    if (!container) return;
    const data = await apiCall('get-best-sellers');
    if (data.success && data.products && data.products.length > 0) {
        container.innerHTML = data.products.map(p => createProductCard(p)).join('');
        attachProductEvents();
    }
}

function createProductCard(product) {
    const discountPercent = product.discount_percent ?
        `<span class="product-badge discount">-${product.discount_percent}%</span>` : '';
    const newBadge = product.is_new ?
        `<span class="product-badge new">جدید</span>` : '';
    const bestSellerBadge = product.is_best_seller ?
        `<span class="product-badge best-seller">پرفروش</span>` : '';
    const oldPriceHtml = product.old_price && product.old_price > product.price ?
        `<span class="old-price">${formatPrice(product.old_price)} تومان</span>` : '';

    let starsHtml = '';
    const rating = product.rating_avg || 0;
    for (let i = 1; i <= 5; i++) {
        starsHtml += i <= rating ? '⭐' : '☆';
    }

    return `
        <div class="product-card" data-product-id="${product.id}">
            <div class="product-image">
                <img src="${product.image || 'images/placeholder.jpg'}" alt="${product.name_fa}" loading="lazy">
                <div class="product-badges">
                    ${discountPercent}${newBadge}${bestSellerBadge}
                </div>
            </div>
            <div class="product-info">
                <h3 class="product-title">${product.name_fa}</h3>
                <div class="product-rating">
                    <div class="stars">${starsHtml}</div>
                    <span class="rating-count">(${product.review_count || 0})</span>
                </div>
                <div class="product-price">
                    <span class="current-price">${formatPrice(product.price)} تومان</span>
                    ${oldPriceHtml}
                </div>
                <button class="add-to-cart" data-product-id="${product.id}">افزودن به سبد خرید</button>
            </div>
        </div>
    `;
}

function attachProductEvents() {
    document.querySelectorAll('.add-to-cart').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await addToCart(btn.dataset.productId);
        });
    });
    document.querySelectorAll('.product-card').forEach(card => {
        card.addEventListener('click', (e) => {
            if (!e.target.classList.contains('add-to-cart')) {
                window.location.href = `product-detail.html?id=${card.dataset.productId}`;
            }
        });
    });
}

// ========== سبد خرید ==========
async function addToCart(productId, quantity = 1) {
    const data = await apiCall('add-to-cart', 'POST', { product_id: productId, quantity });
    if (data.success) {
        showMessage('✓ به سبد خرید اضافه شد');
        updateCartCount();
    } else if (data.error === 'Please login') {
        showMessage('لطفاً ابتدا وارد شوید', true);
        showAuthModal();
    } else {
        showMessage(data.error || 'خطا در افزودن به سبد', true);
    }
}

async function updateCartCount() {
    const data = await apiCall('get-cart');
    const cartCountSpan = document.querySelector('.cart-count');
    if (data.success && cartCountSpan) {
        cartCountSpan.textContent = data.count || 0;
    }
}

// ========== احراز هویت ==========
async function checkAuth() {
    const data = await apiCall('check-auth');
    const userNameSpan = document.getElementById('userName');
    if (!userNameSpan) return;
    if (data.logged_in) {
        userNameSpan.textContent = data.fullname;
    } else {
        userNameSpan.textContent = 'ورود';
    }
}

async function loginUser(email, password) {
    const data = await apiCall('login', 'POST', { email, password });
    if (data.success) {
        showMessage(`خوش آمدید ${data.fullname}`);
        closeAuthModal();
        
        // بررسی ادمین بودن
        if (data.is_admin == 1) {
            window.location.href = 'admin/dashboard.html';
        } else {
            window.location.reload();
        }
    } else {
        showMessage(data.error || 'ایمیل یا رمز عبور اشتباه است', true);
    }
}

async function registerUser(fullname, email, password, phone) {
    const data = await apiCall('register', 'POST', { fullname, email, password, phone });
    if (data.success) {
        showMessage('ثبت‌نام با موفقیت انجام شد');
        closeAuthModal();
        setTimeout(() => location.reload(), 500);
    } else {
        showMessage(data.error || 'خطا در ثبت‌نام', true);
    }
}

async function logoutUser() {
    const data = await apiCall('logout');
    if (data.success) {
        showMessage('خروج با موفقیت انجام شد');
        setTimeout(() => location.reload(), 500);
    }
}

// ========== علاقه‌مندی‌ها ==========
async function loadWishlistCount() {
    const wishlistCountSpan = document.querySelector('.wishlist-count');
    if (!wishlistCountSpan) return;
    const data = await apiCall('get-wishlist');
    if (data.success) {
        wishlistCountSpan.textContent = data.products?.length || 0;
    }
}

// ========== مودال احراز هویت ==========
function showAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    }
}

function closeAuthModal() {
    const modal = document.getElementById('authModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

// ========== راه‌اندازی مودال ==========
function setupAuthModal() {
    const modal = document.getElementById('authModal');
    if (!modal) return;

    const closeBtn = document.getElementById('closeAuthModalBtn');
    if (closeBtn) closeBtn.onclick = closeAuthModal;
    modal.onclick = (e) => { if (e.target === modal) closeAuthModal(); };

    // فرم ورود
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.onsubmit = (e) => {
            e.preventDefault();
            const email = document.getElementById('loginEmail').value.trim();
            const password = document.getElementById('loginPassword').value;
            if (!email || !password) {
                showMessage('لطفاً ایمیل و رمز عبور را وارد کنید', true);
                return;
            }
            loginUser(email, password);
        };
    }

    // فرم ثبت‌نام — آی‌دی فیلدها یکسان‌سازی شد: registerName
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.onsubmit = (e) => {
            e.preventDefault();
            // ✅ اصلاح: همه صفحات از registerName استفاده می‌کنند
            const name = document.getElementById('registerName').value.trim();
            const email = document.getElementById('registerEmail').value.trim();
            const password = document.getElementById('registerPassword').value;
            const phone = document.getElementById('registerPhone')?.value || '';
            if (!name || !email || !password) {
                showMessage('لطفاً تمام فیلدهای الزامی را پر کنید', true);
                return;
            }
            if (password.length < 6) {
                showMessage('رمز عبور باید حداقل ۶ کاراکتر باشد', true);
                return;
            }
            registerUser(name, email, password, phone);
        };
    }

    // تغییر بین فرم‌ها
    const switchToReg = document.getElementById('switchToRegister');
    const switchToLog = document.getElementById('switchToLogin');
    const modalTitle = document.getElementById('modalTitle');

    if (switchToReg) {
        switchToReg.onclick = (e) => {
            e.preventDefault();
            if (loginForm) loginForm.style.display = 'none';
            if (registerForm) registerForm.style.display = 'block';
            switchToReg.style.display = 'none';
            if (switchToLog) switchToLog.style.display = 'inline';
            if (modalTitle) modalTitle.textContent = 'ثبت‌نام در One Target';
        };
    }
    if (switchToLog) {
        switchToLog.onclick = (e) => {
            e.preventDefault();
            if (loginForm) loginForm.style.display = 'block';
            if (registerForm) registerForm.style.display = 'none';
            if (switchToReg) switchToReg.style.display = 'inline';
            switchToLog.style.display = 'none';
            if (modalTitle) modalTitle.textContent = 'ورود به حساب کاربری';
        };
    }
}

// ========== دسته‌بندی‌ها در فوتر ==========
async function loadFooterCategories() {
    const container = document.getElementById('footerCategories');
    if (!container || container.innerHTML.trim()) return;
    const data = await apiCall('get-categories');
    if (data.success && data.categories) {
        container.innerHTML = data.categories.slice(0, 6).map(cat =>
            `<li><a href="products.html?category=${cat.slug}">${cat.name}</a></li>`
        ).join('');
    }
}

// ========== اجرا ==========
document.addEventListener('DOMContentLoaded', async () => {
    setupAuthModal();
    await loadFeaturedProducts();
    await loadNewProducts();
    await loadBestSellers();
    await checkAuth();
    await updateCartCount();
    await loadWishlistCount();

    // دکمه کاربر (ورود/خروج) — بعد از لود هدر هم در components.js اتچ می‌شه
    const userBtn = document.getElementById('userBtn');
    if (userBtn) {
        userBtn.addEventListener('click', () => {
            const userNameSpan = document.getElementById('userName');
            if (userNameSpan && userNameSpan.textContent === 'ورود') {
                showAuthModal();
            }
        });
    }

    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', async (e) => {
            e.preventDefault();
            await logoutUser();
        });
    }
});
