// js/wishlist.js
// توجه: API_URL، formatPrice، showMessage، apiCall از main.js میان

async function loadWishlist() {
    const data = await apiCall('get-wishlist');

    if (data.success) {
        document.getElementById('loadingSpinner').style.display = 'none';
        if (data.products && data.products.length > 0) {
            displayWishlist(data.products);
            document.getElementById('wishlistContent').style.display = 'block';
        } else {
            document.getElementById('emptyWishlist').style.display = 'block';
        }
    } else if (data.error === 'Please login') {
        window.location.href = 'index.html';
    } else {
        document.getElementById('loadingSpinner').innerHTML = '<p class="error">خطا در بارگذاری</p>';
    }
}

function displayWishlist(products) {
    const container = document.getElementById('wishlistGrid');
    const countSpan = document.getElementById('wishlistCount');
    if (!container) return;

    if (countSpan) countSpan.textContent = `${products.length} محصول در لیست علاقه‌مندی‌ها`;

    container.innerHTML = products.map(product => `
        <div class="wishlist-card">
            <div class="wishlist-card-image">
                <img src="${product.image || 'images/placeholder.jpg'}" alt="${product.name_fa}"
                     onclick="location.href='product-detail.html?id=${product.id}'" style="cursor:pointer">
                <button class="remove-wishlist-btn" data-product-id="${product.id}" title="حذف">✕</button>
            </div>
            <div class="wishlist-card-info">
                <div class="wishlist-card-title" onclick="location.href='product-detail.html?id=${product.id}'" style="cursor:pointer">${product.name_fa}</div>
                <div class="wishlist-card-price">
                    ${formatPrice(product.price)} تومان
                    ${product.old_price && product.old_price > product.price ?
                        `<span class="wishlist-card-old-price">${formatPrice(product.old_price)} تومان</span>` : ''}
                </div>
                <div class="wishlist-card-actions">
                    <button class="move-to-cart" data-product-id="${product.id}">🛒 افزودن به سبد</button>
                    <button class="remove-item" data-product-id="${product.id}">🗑️ حذف</button>
                </div>
            </div>
        </div>
    `).join('');

    container.querySelectorAll('.remove-wishlist-btn, .remove-item').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            await removeFromWishlist(btn.dataset.productId);
        });
    });

    container.querySelectorAll('.move-to-cart').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            e.stopPropagation();
            const result = await apiCall('add-to-cart', 'POST', { product_id: btn.dataset.productId, quantity: 1 });
            if (result.success) {
                showMessage('به سبد خرید اضافه شد');
                updateCartCount();
                await removeFromWishlist(btn.dataset.productId);
            } else if (result.error === 'Please login') {
                showAuthModal();
            } else {
                showMessage(result.error || 'خطا', true);
            }
        });
    });
}

async function removeFromWishlist(productId) {
    const result = await apiCall('toggle-wishlist', 'POST', { product_id: productId });
    if (result.success) {
        showMessage('از علاقه‌مندی‌ها حذف شد');
        await loadWishlist();
        loadWishlistCount();
    }
}

function setupClearAll() {
    const clearBtn = document.getElementById('clearAllWishlist');
    if (!clearBtn) return;
    clearBtn.addEventListener('click', async () => {
        if (confirm('آیا از حذف همه محصولات از لیست علاقه‌مندی‌ها مطمئن هستید؟')) {
            const data = await apiCall('get-wishlist');
            if (data.success && data.products && data.products.length > 0) {
                for (const product of data.products) {
                    await apiCall('toggle-wishlist', 'POST', { product_id: product.id });
                }
                showMessage('همه محصولات حذف شدند');
                await loadWishlist();
                loadWishlistCount();
            }
        }
    });
}

document.addEventListener('DOMContentLoaded', () => {
    loadWishlist();
    setupClearAll();
});
