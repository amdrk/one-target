<?php
// ai/assistant.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ========== تنظیمات LM Studio ==========
$LM_STUDIO_URL = 'http://127.0.0.1:1234/v1/chat/completions';

// ========== تنظیمات دیتابیس ==========
$host = 'localhost';
$dbname = 'one_target_db';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die(json_encode(['success' => false, 'error' => 'Database connection failed']));
}

// ========== دریافت درخواست ==========
$input = json_decode(file_get_contents('php://input'), true);
$userMessage = trim($input['message'] ?? '');
$chatHistory = $input['history'] ?? [];

if (empty($userMessage)) {
    echo json_encode(['success' => false, 'error' => 'پیامی ارسال نشده است']);
    exit();
}

// ========== جستجوی هوشمند محصولات بر اساس سوال ==========
$products = searchProducts($userMessage, $pdo);

// ========== ساخت پرامپت ==========
$systemPrompt = buildSystemPrompt();
$userPrompt = buildUserPrompt($userMessage, $products);

// ========== ارسال به LM Studio ==========
$response = callLMStudio($systemPrompt, $userPrompt, $chatHistory);

if ($response['success']) {
    echo json_encode([
        'success' => true,
        'reply' => $response['reply'],
        'products' => $products
    ]);
} else {
    echo json_encode([
        'success' => false,
        'error' => $response['error'] ?? 'خطا در ارتباط با LM Studio'
    ]);
}

// ========== توابع ==========

/**
 * ✅ جستجوی هوشمند محصولات بر اساس کلمات کلیدی
 */
function searchProducts($query, $pdo) {
    // کلمات کلیدی برای شناسایی دسته‌بندی
    $keywords = [
        'ram' => ['رم', 'حافظه', 'memory', 'ddr', 'ram'],
        'gpu' => ['کارت گرافیک', 'گرافیک', 'gpu', 'rtx', 'gtx', 'radeon'],
        'cpu' => ['پردازنده', 'cpu', 'core', 'اینتل', 'amd', 'ryzen'],
        'motherboard' => ['مادربرد', 'motherboard', 'z790', 'b760', 'x670'],
        'ssd' => ['ssd', 'اس اس دی', 'حافظه固态', 'nvme', 'sata'],
        'psu' => ['منبع تغذیه', 'پاور', 'psu', 'وات', 'power supply'],
        'case' => ['کیس', 'case', 'کیس گیمینگ', 'مخزن'],
        'cooler' => ['خنک کننده', 'cooler', 'فن', 'آبی', 'liquid'],
        'monitor' => ['مانیتور', 'monitor', 'صفحه نمایش', '4k', '144hz'],
        'accessories' => ['لوازم جانبی', 'کیبورد', 'ماوس', 'هدفون', 'accessories']
    ];
    
    // شناسایی دسته‌بندی مورد نظر کاربر
    $targetCategory = null;
    $queryLower = mb_strtolower($query);
    
    foreach ($keywords as $category => $words) {
        foreach ($words as $word) {
            if (mb_strpos($queryLower, $word) !== false) {
                $targetCategory = $category;
                break 2;
            }
        }
    }
    
    // جستجو در دیتابیس
    if ($targetCategory) {
        // اگر دسته‌بندی مشخص شد، فقط محصولات همون دسته رو برگردون
        $categoryMap = [
            'ram' => 'رم',
            'gpu' => 'کارت گرافیک',
            'cpu' => 'پردازنده',
            'motherboard' => 'مادربرد',
            'ssd' => 'اس اس دی',
            'psu' => 'منبع تغذیه',
            'case' => 'کیس',
            'cooler' => 'خنک کننده',
            'monitor' => 'مانیتور',
            'accessories' => 'لوازم جانبی'
        ];
        
        $categoryName = $categoryMap[$targetCategory] ?? null;
        if ($categoryName) {
            $stmt = $pdo->prepare("SELECT id, name_fa, brand, price, old_price, discount_percent, image, stock 
                                   FROM products 
                                   WHERE category_id = (SELECT id FROM categories WHERE name LIKE ?) 
                                   AND stock > 0 
                                   ORDER BY 
                                       CASE 
                                           WHEN name_fa LIKE ? THEN 1
                                           WHEN brand LIKE ? THEN 2
                                           ELSE 3
                                       END
                                   LIMIT 10");
            $searchTerm = "%$query%";
            $stmt->execute(["%$categoryName%", $searchTerm, $searchTerm]);
            $results = $stmt->fetchAll();
            
            if (!empty($results)) {
                return $results;
            }
        }
    }
    
    // اگر دسته‌بندی مشخص نشد یا محصولی پیدا نشد، جستجوی عمومی
    $searchTerm = "%$query%";
    $stmt = $pdo->prepare("SELECT id, name_fa, brand, price, old_price, discount_percent, image, stock 
                           FROM products 
                           WHERE (name_fa LIKE ? OR brand LIKE ? OR description LIKE ?) 
                           AND stock > 0 
                           LIMIT 10");
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
    $results = $stmt->fetchAll();
    
    // اگه هیچی پیدا نشد، محصولات ویژه رو برگردون
    if (empty($results)) {
        $stmt = $pdo->query("SELECT id, name_fa, brand, price, old_price, discount_percent, image, stock 
                             FROM products WHERE is_featured = 1 AND stock > 0 LIMIT 5");
        $results = $stmt->fetchAll();
    }
    
    return $results;
}

/**
 * ساخت پرامپت سیستم
 */
function buildSystemPrompt() {
    return "تو یک دستیار فروشگاهی هوشمند به نام وان‌تارگت هستی.
    
    وظیفه‌ات: پاسخ به سوالات کاربران در مورد قطعات کامپیوتر و پیشنهاد بهترین محصولات بر اساس نیازشان.

    قوانین مهم:
    1. فقط به زبان فارسی پاسخ بده.
    2. پاسخ‌ها رو مختصر، مفید و دوستانه بگو.
    3. اگر کاربر سوالی خارج از موضوع قطعات کامپیوتر پرسید، مودبانه بگو که فقط در این زمینه راهنمایی میکنی.
    4. اگر محصولی برای پیشنهاد داری، حتماً نام محصول و قیمت رو ذکر کن.
    5. اگر اطلاعات کافی نداری، از کاربر توضیح بیشتر بخواه.";
}

/**
 * ساخت پرامپت کاربر با محصولات پیدا شده
 */
function buildUserPrompt($message, $products) {
    $productList = '';
    if (!empty($products)) {
        foreach ($products as $i => $p) {
            $discount = $p['discount_percent'] ? " (${p['discount_percent']}% تخفیف)" : '';
            $productList .= ($i + 1) . ". {$p['name_fa']} - برند: " . ($p['brand'] ?? 'نامشخص') . " - قیمت: " . number_format($p['price']) . " تومان{$discount}\n";
        }
    } else {
        $productList = "هیچ محصول مرتبطی پیدا نشد.";
    }
    
    return "سوال کاربر: $message
    
    محصولات مرتبط پیدا شده در فروشگاه:
    $productList
    
    لطفاً بر اساس اطلاعات بالا، بهترین پاسخ را به کاربر بده. اگر محصولات مرتبطی پیدا نشد، از کاربر بخواه توضیح بیشتری بدهد.";
}

/**
 * ارسال درخواست به LM Studio
 */
function callLMStudio($systemPrompt, $userPrompt, $history = []) {
    $messages = [['role' => 'system', 'content' => $systemPrompt]];
    
    if (count($history) > 0) {
        $history = array_slice($history, -5);
        foreach ($history as $msg) {
            $messages[] = ['role' => $msg['role'], 'content' => $msg['content']];
        }
    }
    
    $messages[] = ['role' => 'user', 'content' => $userPrompt];
    
    // $payload = [
    //     'model' => 'gemma-3-1b-it-qat',
    //     'messages' => $messages,
    //     'temperature' => 0.7,
    //     'max_tokens' => 300,
    //     'stream' => false
    // ];

    $payload = [
    'model' => 'gemma-3n-e4b-it-text',   // ← مدل جدید
    'messages' => $messages,
    'temperature' => 0.3,                // ← کمتر برای دقت بیشتر
    'max_tokens' => 200,                 // ← کمتر برای پاسخ کوتاه‌تر
    'stream' => false
];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:1234/v1/chat/completions');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    if ($error) {
        return ['success' => false, 'error' => 'cURL Error: ' . $error];
    }
    
    if ($httpCode !== 200) {
        return ['success' => false, 'error' => "HTTP Error: $httpCode"];
    }
    
    $data = json_decode($response, true);
    if (isset($data['choices'][0]['message']['content'])) {
        return ['success' => true, 'reply' => $data['choices'][0]['message']['content']];
    }
    
    return ['success' => false, 'error' => 'پاسخ نامعتبر'];
}